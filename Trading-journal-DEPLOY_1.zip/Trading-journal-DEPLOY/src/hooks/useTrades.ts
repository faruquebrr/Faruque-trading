import { useState, useEffect } from 'react';
import { Trade, Settings } from '../types';
import { getTradingSession } from '../lib/utils';

export function useTrades() {
  const [trades, setTrades] = useState<Trade[]>([]);
  // ... existing settings ...
  const [settings, setSettings] = useState<Settings>({
    defaultLotSize: 0.01,
    defaultLots: {
      'XAUUSD': 0.03,
      'BTCUSD': 0.10,
    },
    maxDailyRisk: 50,
    initialCapital: 1000,
  });

  useEffect(() => {
    const savedTrades = localStorage.getItem('goldJournalTrades');
    if (savedTrades) {
      setTrades(JSON.parse(savedTrades));
    }

    const savedSettings = localStorage.getItem('goldJournalSettings');
    if (savedSettings) {
      setSettings(prev => ({
        ...prev,
        ...JSON.parse(savedSettings)
      }));
    }
  }, []);

  const addTrade = (trade: Trade) => {
    const tradeWithSession = {
      ...trade,
      session: trade.session || getTradingSession()
    };
    const updatedTrades = [...trades, tradeWithSession];
    setTrades(updatedTrades);
    localStorage.setItem('goldJournalTrades', JSON.stringify(updatedTrades));
  };

  const updateTrade = (updatedTrade: Trade) => {
    const updatedTrades = trades.map((t) => (t.id === updatedTrade.id ? updatedTrade : t));
    setTrades(updatedTrades);
    localStorage.setItem('goldJournalTrades', JSON.stringify(updatedTrades));
  };

  const deleteTrade = (id: string) => {
    const updatedTrades = trades.filter((t) => t.id !== id);
    setTrades(updatedTrades);
    localStorage.setItem('goldJournalTrades', JSON.stringify(updatedTrades));
  };

  const resetAll = () => {
    setTrades([]);
    localStorage.setItem('goldJournalTrades', JSON.stringify([]));
  };

  const updateSettings = (newSettings: Settings) => {
    setSettings(newSettings);
    localStorage.setItem('goldJournalSettings', JSON.stringify(newSettings));
  };

  const importTrades = (newTrades: Trade[], overwrite: boolean = false) => {
    const updatedTrades = overwrite ? newTrades : [...trades, ...newTrades];
    setTrades(updatedTrades);
    localStorage.setItem('goldJournalTrades', JSON.stringify(updatedTrades));
  };

  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (trades.length > 0) e.preventDefault();
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [trades.length]);

  return {
    trades,
    settings,
    addTrade,
    updateTrade,
    deleteTrade,
    resetAll,
    updateSettings,
    importTrades,
  };
}
