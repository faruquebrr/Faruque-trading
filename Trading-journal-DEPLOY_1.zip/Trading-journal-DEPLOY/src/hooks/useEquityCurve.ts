import { useMemo } from 'react';
import { Trade } from '../types';

export function useEquityCurve(trades: Trade[], initialCapital: number) {
  return useMemo(() => {
    let balance = Number(initialCapital) || 1000;
    let peak = balance;
    let maxDrawdown = 0;
    const data = [{ name: '0', balance, peak, date: 'Start' }];
    
    trades
      .filter(t => t.status === 'CLOSED')
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .forEach((t, i) => {
        balance += t.pnl || 0;
        if (balance > peak) peak = balance;
        const dd = peak - balance;
        if (dd > maxDrawdown) maxDrawdown = dd;
        data.push({ 
          name: (i + 1).toString(), 
          balance: parseFloat(balance.toFixed(2)), 
          peak: parseFloat(peak.toFixed(2)),
          date: new Date(t.date).toLocaleDateString([], { month: 'short', day: 'numeric' }) 
        });
      });
      
    return { data, maxDrawdown, currentBalance: balance };
  }, [trades, initialCapital]);
}
