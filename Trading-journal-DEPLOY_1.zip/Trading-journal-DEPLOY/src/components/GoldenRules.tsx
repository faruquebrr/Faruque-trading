import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles } from 'lucide-react';

const RULES = [
  "If you touch a trade before TP or SL, you must log it immediately.",
  "Fear makes you close winners early. Greed makes you hold losers too long.",
  "One good trade does not make you a pro. One disciplined week does.",
  "Check your emotions before checking your charts.",
  "Did you follow the plan? If no, don't trade again today.",
  "A small consistent edge compounds into extraordinary results.",
  "The market doesn't care about your feelings. Your journal does.",
];

export function GoldenRules() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex(prev => (prev + 1) % RULES.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bento-card !p-4 bg-slate-900 border-primary/10 text-white flex flex-row items-center gap-4">
      <div className="bg-primary p-2 rounded-xl shrink-0">
        <Sparkles className="w-4 h-4 text-white" />
      </div>
      <div className="min-w-0 flex-1">
        <span className="text-[9px] font-black text-primary uppercase tracking-[0.2em] block mb-0.5">Trader's Philosophy</span>
        <AnimatePresence mode="wait">
          <motion.p
            key={index}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.3 }}
            className="text-[11px] font-medium leading-tight text-white/80"
          >
            {RULES[index]}
          </motion.p>
        </AnimatePresence>
      </div>
    </div>
  );
}
