import React, { useState } from 'react';
import { Trade, ExitReason } from '../types';
import { X, Save, AlertTriangle, CloudRain, Smile, CheckCircle, XCircle, Edit3 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { calculatePnL } from '../lib/utils';

interface ReviewModalProps {
  trade: Trade | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (trade: Trade) => void;
}

const EXIT_REASONS: { value: ExitReason; label: string; icon: React.ReactNode }[] = [
  { value: 'TP', label: 'Take Profit Hit', icon: <CheckCircle className="w-4 h-4 text-green-500" /> },
  { value: 'SL', label: 'Stop Loss Hit', icon: <XCircle className="w-4 h-4 text-red-500" /> },
  { value: 'EA', label: 'EARLY EXIT (Manual)', icon: <AlertTriangle className="w-4 h-4 text-amber-500" /> },
  { value: 'MV', label: 'Moved Stop Manually', icon: <Edit3 className="w-4 h-4 text-amber-500" /> },
];

export function ReviewModal({ trade, isOpen, onClose, onSave }: ReviewModalProps) {
  const [exitPrice, setExitPrice] = useState('');
  const [exitReason, setExitReason] = useState<ExitReason>('');
  const [earlyExitReason, setEarlyExitReason] = useState('');
  const [emotionScore, setEmotionScore] = useState(5);
  const [notes, setNotes] = useState('');
  const [wrongReason, setWrongReason] = useState('');
  const [mentor, setMentor] = useState('');
  const [commission, setCommission] = useState('0');

  // Update state when trade changes
  React.useEffect(() => {
    if (trade) {
      setMentor(trade.mentor || '');
      setCommission(trade.commission?.toString() || '0');
      
      if (trade.status === 'CLOSED') {
        setExitPrice(trade.exitPrice?.toString() || '');
        setExitReason(trade.exitReason || '');
        setEarlyExitReason(trade.earlyExitReason || '');
        setNotes(trade.notes || '');
        setWrongReason(trade.wrongReason || '');
        setEmotionScore(trade.emotionScore || 5);
      } else {
        setExitPrice('');
        setExitReason('');
        setEarlyExitReason('');
        setNotes('');
        setWrongReason('');
        setEmotionScore(5);
      }
    }
  }, [trade]);

  if (!trade) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const exitPriceNum = parseFloat(exitPrice);
    const commissionNum = parseFloat(commission) || 0;
    
    const updatedTrade: Trade = {
      ...trade,
      status: 'CLOSED',
      exitPrice: exitPriceNum,
      exitReason,
      earlyExitReason,
      emotionScore,
      notes,
      wrongReason,
      mentor,
      commission: commissionNum,
      pnl: calculatePnL(trade.entryPrice, exitPriceNum, trade.lotSize, trade.direction, trade.pair, commissionNum),
    };
    onSave(updatedTrade);
    onClose();
    // Reset local state
    setExitPrice('');
    setExitReason('');
    setEarlyExitReason('');
    setEmotionScore(5);
    setNotes('');
  };

  const isEarly = exitReason === 'EA' || exitReason === 'MV';
  const exitPriceNum = parseFloat(exitPrice) || 0;
  const commissionNum = parseFloat(commission) || 0;
  const grossPnL = trade ? calculatePnL(trade.entryPrice, exitPriceNum, trade.lotSize, trade.direction, trade.pair, 0) : 0;
  const netPnL = grossPnL - commissionNum;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md z-[1000] flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 10 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-slate-900 w-full max-w-lg rounded-2xl shadow-[0_0_50px_rgba(0,0,0,0.5)] border border-white/5 p-8 overflow-hidden relative"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-[40px] -mr-16 -mt-16" />
              
              <div className="flex items-center justify-between mb-10 pb-6 border-b border-white/10 relative z-10">
                <div>
                  <h3 className="card-title text-[10px] font-black uppercase text-primary tracking-[0.3em] flex items-center gap-2 mb-2">
                    <CheckCircle className="w-3 h-3" /> Mission Debriefing
                  </h3>
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] bg-white/5 px-2 py-1 rounded-lg font-mono font-black text-white/50 border border-white/5 tracking-wider">{trade.pair}</span>
                    <p className="text-[11px] font-black text-white/40 font-mono tracking-widest uppercase">
                      ID: {trade.id.toString().slice(-8)}
                    </p>
                  </div>
                </div>
                <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-xl transition-colors">
                  <X className="w-5 h-5 text-text-dim" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-8 relative z-10">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="bento-label !text-white/40">Termination Price</label>
                    <div className="relative group">
                      <input
                        type="number"
                        step="0.01"
                        value={exitPrice}
                        onChange={(e) => setExitPrice(e.target.value)}
                        placeholder="0.00"
                        className="bento-input font-mono font-bold text-lg p-3 bg-black/40 border-white/5 focus:border-primary/50"
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="bento-label !text-white/40">Operational Fees</label>
                    <input
                      type="number"
                      step="0.01"
                      value={commission}
                      onChange={(e) => setCommission(e.target.value)}
                      placeholder="0.00"
                      className="bento-input font-mono text-lg p-3 bg-black/40 border-white/5 focus:border-primary/50"
                    />
                  </div>
                </div>

                {exitPrice && (
                  <div className="bg-black/40 p-5 rounded-2xl border border-white/5 shadow-inner flex items-center justify-between">
                    <div className="space-y-1">
                      <span className="text-[8px] font-black uppercase text-white/20 tracking-widest block">Yield Projection</span>
                      <div className="flex items-center gap-4">
                        <div className="text-[10px] font-mono font-bold text-white/40">
                          Gross: <span className={grossPnL >= 0 ? 'text-success' : 'text-danger'}>${grossPnL.toFixed(2)}</span>
                        </div>
                        <div className="text-[10px] font-mono font-bold text-white/40">
                          Fees: <span className="text-danger">-${commissionNum.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                       <span className="text-[8px] font-black uppercase text-white/20 tracking-widest block mb-1">Net Gain/Loss</span>
                       <div className={`text-2xl font-black font-mono leading-none ${netPnL >= 0 ? 'text-success drop-shadow-[0_0_10px_rgba(16,185,129,0.3)]' : 'text-danger drop-shadow-[0_0_10px_rgba(244,63,94,0.3)]'}`}>
                        {netPnL >= 0 ? '+' : ''}{netPnL.toFixed(2)}
                       </div>
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  <label className="bento-label !text-white/40">Result Protocol</label>
                  <div className="grid grid-cols-2 gap-3">
                    {EXIT_REASONS.map((r) => (
                      <button
                        key={r.value}
                        type="button"
                        onClick={() => setExitReason(r.value)}
                        className={`group flex items-center gap-3 px-4 py-3 rounded-xl border-2 transition-all text-left relative overflow-hidden ${
                          exitReason === r.value
                            ? 'border-primary bg-primary/10 text-white'
                            : 'border-white/5 bg-black/20 hover:border-white/20 text-text-dim'
                        }`}
                      >
                        {exitReason === r.value && (
                          <motion.div layoutId="reason-glitch" className="absolute inset-0 bg-primary/5 animate-pulse" />
                        )}
                        <div className="relative z-10 shrink-0">
                          {r.icon}
                        </div>
                        <span className="text-[11px] font-black leading-none uppercase tracking-tight relative z-10">
                          {r.label}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                <AnimatePresence>
                  {isEarly && (
                    <motion.div
                      initial={{ height: 0, opacity: 0, scale: 0.95 }}
                      animate={{ height: 'auto', opacity: 1, scale: 1 }}
                      exit={{ height: 0, opacity: 0, scale: 0.95 }}
                      className="overflow-hidden"
                    >
                      <div className="space-y-2 bg-danger/5 p-5 rounded-2xl border border-danger/20 ring-1 ring-danger/5">
                        <label className="text-[9px] font-black text-danger uppercase tracking-[0.2em] block mb-2">
                           Deviation Root Cause
                        </label>
                        <textarea
                          value={earlyExitReason}
                          onChange={(e) => setEarlyExitReason(e.target.value)}
                          placeholder="Fear? Impatience? Describe deviation..."
                          className="w-full bg-black/40 px-4 py-3 border border-white/5 rounded-xl focus:outline-none focus:border-danger/50 text-xs font-medium text-white/80 resize-none h-20 placeholder:text-white/10"
                          required={exitReason === 'EA'}
                        />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="space-y-5">
                  <div className="flex justify-between items-center">
                    <label className="bento-label !mb-0 !text-white/40">Neural Engagement Score</label>
                    <span className="font-mono text-[12px] font-black text-primary bg-primary/10 px-3 py-1 rounded-lg border border-primary/20">
                      {emotionScore} <span className="text-[8px] opacity-40">/10</span>
                    </span>
                  </div>
                  <div className="px-1 relative">
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={emotionScore}
                      onChange={(e) => setEmotionScore(parseInt(e.target.value))}
                      className="w-full h-1.5 bg-white/5 rounded-lg appearance-none cursor-pointer accent-primary"
                    />
                    <div className="flex justify-between mt-3">
                      <span className="text-[8px] text-white/20 uppercase font-black tracking-widest font-mono">Chaos/Fear</span>
                      <span className="text-[8px] text-white/20 uppercase font-black tracking-widest font-mono">Zen/Flow</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="bento-label flex items-center gap-2 !text-white/40">
                    <AlertTriangle className="w-3 h-3 text-danger" />
                    Operational Friction (What went wrong?)
                  </label>
                  <textarea
                    value={wrongReason}
                    onChange={(e) => setWrongReason(e.target.value)}
                    placeholder="Execution errors, hesitation, emotional slip-ups..."
                    rows={2}
                    className="bento-input resize-none h-16 text-[11px] bg-black/40 border-white/10"
                  />
                </div>

                <div className="pt-4">
                  <button
                    type="submit"
                    disabled={!exitReason}
                    className="bento-button w-full h-14 flex items-center justify-center gap-3 bg-gradient-to-r from-primary to-blue-700 shadow-[0_0_30px_rgba(59,130,246,0.2)] hover:shadow-[0_0_40px_rgba(59,130,246,0.4)] disabled:opacity-20 transition-all active:scale-[0.98]"
                  >
                    <Save className="w-5 h-5" />
                    Archive Execution Logs
                  </button>
                  <p className="text-[9px] text-center text-text-dim mt-4 uppercase tracking-[0.3em] font-black opacity-20">
                    End of Trading Session Entry
                  </p>
                </div>
              </form>
            </motion.div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
