import React, { useMemo } from 'react';
import { Trade } from '../types';
import { Calendar, TrendingUp, TrendingDown, AlertTriangle, CheckCircle } from 'lucide-react';
import { cn, calcRealizedRR } from '../lib/utils';

interface WeeklySummaryProps {
  trades: Trade[];
}

export function WeeklySummary({ trades }: WeeklySummaryProps) {
  const stats = useMemo(() => {
    const now = new Date();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay());
    startOfWeek.setHours(0, 0, 0, 0);

    const weeklyTrades = trades.filter(t => {
      const tradeDate = new Date(t.date);
      return tradeDate >= startOfWeek && t.status === 'CLOSED';
    });

    if (weeklyTrades.length === 0) return null;

    const pnl = weeklyTrades.reduce((acc, t) => acc + (t.pnl || 0), 0);
    const wins = weeklyTrades.filter(t => (t.pnl || 0) > 0).length;
    const losses = weeklyTrades.filter(t => (t.pnl || 0) < 0).length;
    const winRate = (wins / weeklyTrades.length) * 100;

    // Realized avg R:R this week
    const rrValues = weeklyTrades.map(t => calcRealizedRR(t)).filter(r => r !== 0);
    const avgRR = rrValues.length > 0 ? rrValues.reduce((a, b) => a + b, 0) / rrValues.length : 0;

    // Discipline rate: trades that hit TP or SL (not manually closed)
    const disciplined = weeklyTrades.filter(t => t.exitReason === 'TP' || t.exitReason === 'SL').length;
    const discRate = (disciplined / weeklyTrades.length) * 100;

    // Worst setup by P&L loss
    const setupLosses: Record<string, number> = {};
    weeklyTrades.forEach(t => {
      if (t.setup && (t.pnl || 0) < 0) {
        setupLosses[t.setup] = (setupLosses[t.setup] || 0) + (t.pnl || 0);
      }
    });
    const worstSetup = Object.entries(setupLosses).sort((a, b) => a[1] - b[1])[0];

    // Emotion most common on losing trades
    const emotionLosses: Record<string, number> = {};
    weeklyTrades.filter(t => (t.pnl || 0) < 0).forEach(t => {
      if (t.preEmotion) emotionLosses[t.preEmotion] = (emotionLosses[t.preEmotion] || 0) + 1;
    });
    const worstEmotion = Object.entries(emotionLosses).sort((a, b) => b[1] - a[1])[0];

    return {
      pnl, winRate, total: weeklyTrades.length, wins, losses,
      avgRR, discRate,
      criticalLeak: worstSetup
        ? `High losses on ${worstSetup[0]} (${worstSetup[1].toFixed(2)})`
        : 'No critical setup failure',
      emotionWarning: worstEmotion && worstEmotion[1] >= 2
        ? `${worstEmotion[0]} linked to ${worstEmotion[1]} losses`
        : null,
    };
  }, [trades]);

  if (!stats) {
    return (
      <div className="bento-card border-white/5 bg-slate-900/40 p-12 text-center opacity-50 h-full flex flex-col items-center justify-center">
        <Calendar className="w-8 h-8 text-white/20 mx-auto mb-4" />
        <p className="text-[10px] font-black uppercase tracking-widest text-white/40">No trades this week yet</p>
        <p className="text-[9px] text-white/20 mt-2">Close a trade to activate weekly metrics</p>
      </div>
    );
  }

  return (
    <div className="bento-card border-white/5 bg-slate-900/60 p-6 relative overflow-hidden group h-full">
      <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:scale-110 transition-transform duration-500">
        <Calendar className="w-12 h-12 text-white" />
      </div>

      <div className="relative z-10 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[9px] font-black uppercase text-primary tracking-[0.3em] mb-1 block">This Week</span>
            <h2 className="text-base font-black text-white italic tracking-tight">WEEKLY REVIEW</h2>
          </div>
          <div className={cn(
            "px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-2",
            stats.pnl >= 0 ? "bg-success/10 text-success border border-success/20" : "bg-danger/10 text-danger border border-danger/20"
          )}>
            {stats.pnl >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {stats.pnl >= 0 ? '+' : ''}${stats.pnl.toFixed(2)}
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: 'Trades', value: stats.total.toString(), color: 'text-white' },
            { label: 'Win Rate', value: `${stats.winRate.toFixed(0)}%`, color: stats.winRate >= 50 ? 'text-success' : 'text-amber-500' },
            { label: 'Avg R:R', value: `${stats.avgRR.toFixed(1)}R`, color: stats.avgRR >= 1.5 ? 'text-success' : stats.avgRR >= 1 ? 'text-amber-500' : 'text-danger' },
            { label: 'Discipline', value: `${stats.discRate.toFixed(0)}%`, color: stats.discRate >= 70 ? 'text-success' : 'text-amber-500' },
          ].map(s => (
            <div key={s.label} className="bg-black/20 rounded-xl p-2.5 text-center border border-white/5">
              <div className="text-[8px] font-black text-white/30 uppercase tracking-widest mb-1">{s.label}</div>
              <div className={`text-base font-black font-mono ${s.color}`}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Warnings / Insights */}
        <div className="space-y-2">
          {stats.criticalLeak !== 'No critical setup failure' && (
            <div className="flex items-start gap-2.5 p-2.5 bg-danger/5 border border-danger/10 rounded-xl">
              <AlertTriangle className="w-3.5 h-3.5 text-danger shrink-0 mt-0.5" />
              <div>
                <span className="text-[8px] font-black text-danger uppercase tracking-widest block mb-0.5">Critical Leak</span>
                <p className="text-[10px] font-bold text-white/60 leading-tight">{stats.criticalLeak}</p>
              </div>
            </div>
          )}
          {stats.emotionWarning && (
            <div className="flex items-start gap-2.5 p-2.5 bg-amber-500/5 border border-amber-500/10 rounded-xl">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <span className="text-[8px] font-black text-amber-500 uppercase tracking-widest block mb-0.5">Emotion Pattern</span>
                <p className="text-[10px] font-bold text-white/60 leading-tight">{stats.emotionWarning}</p>
              </div>
            </div>
          )}
          {stats.criticalLeak === 'No critical setup failure' && !stats.emotionWarning && (
            <div className="flex items-start gap-2.5 p-2.5 bg-success/5 border border-success/10 rounded-xl">
              <CheckCircle className="w-3.5 h-3.5 text-success shrink-0 mt-0.5" />
              <p className="text-[10px] font-bold text-white/60 leading-tight">No critical leaks this week. Stay disciplined.</p>
            </div>
          )}
        </div>
      </div>

      <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
    </div>
  );
}
