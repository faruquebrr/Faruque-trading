import React, { useMemo } from 'react';
import { Trade } from '../types';
import { Zap, ShieldAlert, AlertCircle } from 'lucide-react';
import { cn } from '../lib/utils';

interface StreakTrackerProps {
  trades: Trade[];
}

export function StreakTracker({ trades }: StreakTrackerProps) {
  const streaks = useMemo(() => {
    const closedTrades = [...trades]
      .filter(t => t.status === 'CLOSED')
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    if (closedTrades.length === 0) return { win: 0, loss: 0 };

    let currentWinStreak = 0;
    let currentLossStreak = 0;
    const firstOutcome = (closedTrades[0].pnl || 0) > 0;

    for (const t of closedTrades) {
      const isWin = (t.pnl || 0) > 0;
      if (firstOutcome) {
        if (isWin) currentWinStreak++;
        else break;
      } else {
        if (!isWin) currentLossStreak++;
        else break;
      }
    }

    return { win: currentWinStreak, loss: currentLossStreak };
  }, [trades]);

  const showWarning = streaks.loss >= 3;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className={cn(
          "bento-card border-none p-5 flex items-center justify-between",
          streaks.win > 0 ? "bg-success/10 ring-1 ring-success/20" : "bg-slate-900/40 border border-white/5"
        )}>
          <div>
            <span className="text-[8px] font-black text-white/30 uppercase tracking-[0.2em] mb-1 block">Active Momentum</span>
            <div className="text-xl font-black text-white italic">
              🔥 WIN STREAK: <span className="text-success ml-2">{streaks.win}</span>
            </div>
          </div>
          <Zap className={cn("w-6 h-6", streaks.win > 0 ? "text-success animate-pulse" : "text-white/10")} />
        </div>

        <div className={cn(
          "bento-card border-none p-5 flex items-center justify-between",
          streaks.loss > 0 ? "bg-danger/10 ring-1 ring-danger/20" : "bg-slate-900/40 border border-white/5"
        )}>
          <div>
            <span className="text-[8px] font-black text-white/30 uppercase tracking-[0.2em] mb-1 block">Active Drawdown</span>
            <div className="text-xl font-black text-white italic">
              ⚠️ LOSS STREAK: <span className="text-danger ml-2">{streaks.loss}</span>
            </div>
          </div>
          <ShieldAlert className={cn("w-6 h-6", streaks.loss > 0 ? "text-danger" : "text-white/10")} />
        </div>
      </div>

      {showWarning && (
        <div className="p-4 bg-danger/20 border-2 border-danger/40 rounded-2xl flex items-center gap-4">
          <AlertCircle className="w-5 h-5 text-danger shrink-0" />
          <p className="text-[11px] font-black text-white uppercase tracking-wider">
            🚨 STOP TRADING IMMEDIATELY. Review your process before the next trade.
          </p>
        </div>
      )}
    </div>
  );
}
