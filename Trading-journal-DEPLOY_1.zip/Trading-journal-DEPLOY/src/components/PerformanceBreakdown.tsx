import React, { useMemo } from 'react';
import { Trade } from '../types';
import { Trophy, TrendingDown, Target, Clock, Calendar, BarChart2 } from 'lucide-react';
import { cn } from '../lib/utils';

interface PerformanceBreakdownProps {
  trades: Trade[];
}

export function PerformanceBreakdown({ trades }: PerformanceBreakdownProps) {
  const closedTrades = useMemo(() => trades.filter(t => t.status === 'CLOSED'), [trades]);

  const performance = useMemo(() => {
    const setupStats: Record<string, { pnl: number; wins: number; total: number }> = {};
    const sessionStats: Record<string, { pnl: number; wins: number; total: number }> = {};
    const pairStats: Record<string, { pnl: number; wins: number; total: number }> = {};
    const dayStats: Record<string, { pnl: number; wins: number; total: number }> = {};
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    closedTrades.forEach(t => {
      const pnl = t.pnl || 0;
      const isWin = pnl > 0;
      const day = dayNames[new Date(t.date).getDay()];
      const pairKey = t.pair === 'Other' && t.customPair ? t.customPair : t.pair;

      if (t.setup) {
        if (!setupStats[t.setup]) setupStats[t.setup] = { pnl: 0, wins: 0, total: 0 };
        setupStats[t.setup].pnl += pnl;
        setupStats[t.setup].total += 1;
        if (isWin) setupStats[t.setup].wins += 1;
      }
      if (t.marketSession) {
        if (!sessionStats[t.marketSession]) sessionStats[t.marketSession] = { pnl: 0, wins: 0, total: 0 };
        sessionStats[t.marketSession].pnl += pnl;
        sessionStats[t.marketSession].total += 1;
        if (isWin) sessionStats[t.marketSession].wins += 1;
      }
      if (!pairStats[pairKey]) pairStats[pairKey] = { pnl: 0, wins: 0, total: 0 };
      pairStats[pairKey].pnl += pnl;
      pairStats[pairKey].total += 1;
      if (isWin) pairStats[pairKey].wins += 1;

      if (!dayStats[day]) dayStats[day] = { pnl: 0, wins: 0, total: 0 };
      dayStats[day].pnl += pnl;
      dayStats[day].total += 1;
      if (isWin) dayStats[day].wins += 1;
    });

    const getBestWorst = (data: Record<string, { pnl: number; wins: number; total: number }>) => {
      const entries = Object.entries(data);
      if (entries.length === 0) return { best: null, worst: null, recommended: null };
      const sortedByPnL = [...entries].sort((a, b) => b[1].pnl - a[1].pnl);
      const sortedByWinRate = [...entries].sort((a, b) => (b[1].wins / b[1].total) - (a[1].wins / a[1].total));
      return {
        best: sortedByPnL[0],
        worst: sortedByPnL.length > 1 ? sortedByPnL[sortedByPnL.length - 1] : null,
        recommended: sortedByPnL[0][1].pnl > 0 ? sortedByPnL[0] : (sortedByWinRate[0][1].total > 2 ? sortedByWinRate[0] : null),
      };
    };

    const pairEntries = Object.entries(pairStats).sort((a, b) => b[1].pnl - a[1].pnl);

    return {
      setups: getBestWorst(setupStats),
      sessions: getBestWorst(sessionStats),
      pairs: pairEntries,
      days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map(day => ({
        name: day,
        ...(dayStats[day] || { pnl: 0, wins: 0, total: 0 }),
      })),
    };
  }, [closedTrades]);

  if (closedTrades.length === 0) {
    return (
      <div className="bento-card border-white/5 bg-slate-900/40 p-12 text-center opacity-50">
        <Trophy className="w-8 h-8 text-white/20 mx-auto mb-4" />
        <p className="text-[10px] font-black uppercase tracking-widest">Performance History Unavailable</p>
        <p className="text-[9px] text-white/20 mt-2">Awaiting first closed position</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-2">
        <div className="flex items-center gap-3">
          <div className="w-1.5 h-4 bg-primary rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)]" />
          <h2 className="text-[10px] font-black uppercase text-white/40 tracking-[0.4em]">Performance Breakdown</h2>
        </div>
        {performance.setups.recommended && (
          <div className="bg-success/10 border border-success/20 px-4 py-1.5 rounded-full flex items-center gap-2">
            <Trophy className="w-3.5 h-3.5 text-success" />
            <span className="text-[10px] font-black text-white uppercase tracking-widest">
              Best Edge: <span className="text-success">{performance.setups.recommended[0]}</span>
            </span>
          </div>
        )}
      </div>

      {/* Setup + Session */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bento-card border-white/5 bg-slate-900/40 p-6 space-y-5">
          <div className="flex items-center gap-3 opacity-60">
            <Target className="w-4 h-4 text-primary" />
            <span className="text-[9px] font-black uppercase tracking-widest text-white/60">Setup Performance</span>
          </div>
          <div className="grid grid-cols-2 gap-6">
            {performance.setups.best && (
              <div className="p-4 rounded-2xl bg-success/5 border border-success/10 hover:border-success/30 transition-all relative overflow-hidden group/best">
                <div className="text-[8px] font-black text-success uppercase tracking-[0.2em] mb-2 px-2 py-0.5 bg-success/10 rounded-md inline-block">Best Setup</div>
                <div className="text-xl font-black text-white tracking-tight leading-none mb-2">{performance.setups.best[0]}</div>
                <div className="text-sm font-black font-mono text-success">+${performance.setups.best[1].pnl.toFixed(2)}</div>
                <div className="text-[9px] font-black text-white/30 uppercase tracking-widest mt-1">
                  {((performance.setups.best[1].wins / performance.setups.best[1].total) * 100).toFixed(0)}% WR · {performance.setups.best[1].total} trades
                </div>
                <Trophy className="absolute top-2 right-2 w-6 h-6 text-success/10 group-hover/best:text-success/30 transition-colors" />
              </div>
            )}
            {performance.setups.worst && (
              <div className="p-4 rounded-2xl bg-danger/5 border border-danger/10 hover:border-danger/30 transition-all relative overflow-hidden group/worst">
                <div className="text-[8px] font-black text-danger uppercase tracking-[0.2em] mb-2 px-2 py-0.5 bg-danger/10 rounded-md inline-block">Worst Setup</div>
                <div className="text-xl font-black text-white tracking-tight leading-none mb-2">{performance.setups.worst[0]}</div>
                <div className="text-sm font-black font-mono text-danger">${performance.setups.worst[1].pnl.toFixed(2)}</div>
                <div className="text-[9px] font-black text-white/30 uppercase tracking-widest mt-1">
                  {((performance.setups.worst[1].wins / performance.setups.worst[1].total) * 100).toFixed(0)}% WR · {performance.setups.worst[1].total} trades
                </div>
                <TrendingDown className="absolute top-2 right-2 w-6 h-6 text-danger/10 group-hover/worst:text-danger/30 transition-colors" />
              </div>
            )}
          </div>
        </div>

        <div className="bento-card border-white/5 bg-slate-900/40 p-6 space-y-5">
          <div className="flex items-center gap-3 opacity-60">
            <Clock className="w-4 h-4 text-primary" />
            <span className="text-[9px] font-black uppercase tracking-widest text-white/60">Session Performance</span>
          </div>
          <div className="grid grid-cols-2 gap-6">
            {performance.sessions.best && (
              <div className="p-4 rounded-2xl bg-success/5 border border-success/10 hover:border-success/30 transition-all">
                <div className="text-[8px] font-black text-success uppercase tracking-[0.2em] mb-2 px-2 py-0.5 bg-success/10 rounded-md inline-block">Best Session</div>
                <div className="text-xl font-black text-white tracking-tight leading-none mb-2">{performance.sessions.best[0]}</div>
                <div className="text-sm font-black font-mono text-success">+${performance.sessions.best[1].pnl.toFixed(2)}</div>
                <div className="text-[9px] font-black text-white/30 uppercase tracking-widest mt-1">
                  {((performance.sessions.best[1].wins / performance.sessions.best[1].total) * 100).toFixed(0)}% WR
                </div>
              </div>
            )}
            {performance.sessions.worst && (
              <div className="p-4 rounded-2xl bg-danger/5 border border-danger/10 hover:border-danger/30 transition-all">
                <div className="text-[8px] font-black text-danger uppercase tracking-[0.2em] mb-2 px-2 py-0.5 bg-danger/10 rounded-md inline-block">Worst Session</div>
                <div className="text-xl font-black text-white tracking-tight leading-none mb-2">{performance.sessions.worst[0]}</div>
                <div className="text-sm font-black font-mono text-danger">${performance.sessions.worst[1].pnl.toFixed(2)}</div>
                <div className="text-[9px] font-black text-white/30 uppercase tracking-widest mt-1">
                  {((performance.sessions.worst[1].wins / performance.sessions.worst[1].total) * 100).toFixed(0)}% WR
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Per-Pair Breakdown */}
      {performance.pairs.length > 0 && (
        <div className="bento-card border-white/5 bg-slate-900/40 p-6 space-y-5">
          <div className="flex items-center gap-3 opacity-60">
            <BarChart2 className="w-4 h-4 text-primary" />
            <span className="text-[9px] font-black uppercase tracking-widest text-white/60">Asset Pair Performance</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {performance.pairs.map(([pair, stat]) => (
              <div key={pair} className={cn(
                "p-4 rounded-2xl border transition-all hover:scale-[1.02]",
                stat.pnl >= 0 ? "bg-success/5 border-success/10 hover:border-success/30" : "bg-danger/5 border-danger/10 hover:border-danger/30"
              )}>
                <div className="text-sm font-black text-white uppercase tracking-tight mb-2">{pair}</div>
                <div className={cn("text-lg font-black font-mono", stat.pnl >= 0 ? "text-success" : "text-danger")}>
                  {stat.pnl >= 0 ? '+' : ''}${stat.pnl.toFixed(2)}
                </div>
                <div className="text-[9px] font-black text-white/30 uppercase tracking-widest mt-1">
                  {((stat.wins / stat.total) * 100).toFixed(0)}% WR · {stat.total} trades
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Weekday Matrix */}
      <div className="bento-card border-white/5 bg-slate-900/40 p-6 space-y-5">
        <div className="flex items-center gap-3 opacity-60">
          <Calendar className="w-4 h-4 text-primary" />
          <span className="text-[9px] font-black uppercase tracking-widest text-white/60">Weekday Performance Matrix</span>
        </div>
        <div className="grid grid-cols-5 gap-3">
          {performance.days.map(day => (
            <div key={day.name} className="space-y-3">
              <div className="text-center">
                <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">{day.name}</span>
              </div>
              <div className={cn(
                "p-3 rounded-2xl border transition-all flex flex-col items-center justify-center gap-1",
                day.total === 0 ? "border-white/5 bg-white/2" :
                day.pnl >= 0 ? "border-success/20 bg-success/5" : "border-danger/20 bg-danger/5"
              )}>
                {day.total === 0 ? (
                  <span className="text-[10px] font-black text-white/10 uppercase py-3">N/A</span>
                ) : (
                  <>
                    <span className={cn("text-[12px] font-black font-mono", day.pnl >= 0 ? "text-success" : "text-danger")}>
                      {day.pnl >= 0 ? '+' : ''}{day.pnl.toFixed(0)}
                    </span>
                    <span className="text-[8px] font-black text-white/30 uppercase tracking-widest">
                      {((day.wins / day.total) * 100).toFixed(0)}% WR
                    </span>
                    <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">{day.total} ops</span>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
