import React, { useMemo } from 'react';
import { Trade } from '../types';
import { TrendingUp, Activity, BarChart3, Target, Scale, Zap } from 'lucide-react';
import { cn, calcRealizedRR } from '../lib/utils';
import { useEquityCurve } from '../hooks/useEquityCurve';

interface SummaryDashboardProps {
  trades: Trade[];
  initialCapital: number;
}

export function SummaryDashboard({ trades, initialCapital }: SummaryDashboardProps) {
  const closedTrades = useMemo(() => trades.filter(t => t.status === 'CLOSED'), [trades]);
  const { maxDrawdown, currentBalance } = useEquityCurve(trades, initialCapital);

  const stats = useMemo(() => {
    const totalTrades = closedTrades.length;
    const wins = closedTrades.filter(t => (t.pnl || 0) > 0).length;
    const losses = closedTrades.filter(t => (t.pnl || 0) < 0).length;
    const winRate = totalTrades > 0 ? (wins / totalTrades) * 100 : 0;
    const totalPnL = closedTrades.reduce((acc, t) => acc + (t.pnl || 0), 0);

    const grossWins = closedTrades.filter(t => (t.pnl || 0) > 0).reduce((a, t) => a + (t.pnl || 0), 0);
    const grossLoss = Math.abs(closedTrades.filter(t => (t.pnl || 0) < 0).reduce((a, t) => a + (t.pnl || 0), 0));
    const profitFactor = grossLoss > 0 ? grossWins / grossLoss : grossWins > 0 ? Infinity : 0;

    const avgWin = wins > 0 ? grossWins / wins : 0;
    const avgLoss = losses > 0 ? grossLoss / losses : 0;

    // Expectancy: (WinRate × AvgWin) - (LossRate × AvgLoss)
    const lossRate = totalTrades > 0 ? losses / totalTrades : 0;
    const expectancy = (winRate / 100) * avgWin - lossRate * avgLoss;

    // Realized avg R:R
    const realizedRRs = closedTrades
      .map(t => calcRealizedRR(t))
      .filter(rr => rr !== 0);
    const avgRR = realizedRRs.length > 0
      ? realizedRRs.reduce((a, b) => a + b, 0) / realizedRRs.length
      : 0;

    return { totalPnL, winRate, totalTrades, profitFactor, expectancy, avgRR };
  }, [closedTrades]);

  const todayStats = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const todayTrades = closedTrades.filter(t => t.date.startsWith(today));
    const totalToday = todayTrades.length;
    const winsToday = todayTrades.filter(t => (t.pnl || 0) > 0).length;
    const winRateToday = totalToday > 0 ? (winsToday / totalToday) * 100 : 0;
    const pnlToday = todayTrades.reduce((acc, t) => acc + (t.pnl || 0), 0);
    const openTrades = trades.filter(t => t.status === 'OPEN').length;
    return { totalToday, winRateToday, pnlToday, openTrades };
  }, [closedTrades, trades]);

  const roi = ((currentBalance - (Number(initialCapital) || 1000)) / (Number(initialCapital) || 1000)) * 100;

  return (
    <div className="space-y-6">
      {/* Primary Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          label="Net P&L"
          value={`${stats.totalPnL >= 0 ? '+' : ''}$${Math.abs(stats.totalPnL).toFixed(2)}`}
          subValue={`${roi >= 0 ? '+' : ''}${roi.toFixed(1)}% ROI`}
          icon={<TrendingUp className="w-8 h-8" />}
          colorType={stats.totalPnL >= 0 ? 'success' : 'danger'}
        />
        <MetricCard
          label="Win Rate"
          value={`${stats.winRate.toFixed(1)}%`}
          subValue={`${closedTrades.filter(t => (t.pnl||0)>0).length}W / ${closedTrades.filter(t => (t.pnl||0)<0).length}L / ${stats.totalTrades} total`}
          icon={<Target className="w-8 h-8" />}
          colorType={stats.winRate >= 50 ? 'success' : stats.winRate >= 40 ? 'default' : 'danger'}
        />
        <MetricCard
          label="Profit Factor"
          value={stats.profitFactor === Infinity ? '∞' : stats.profitFactor.toFixed(2)}
          subValue={stats.profitFactor >= 1.5 ? 'Healthy edge' : stats.profitFactor >= 1 ? 'Marginal edge' : 'Losing system'}
          icon={<Scale className="w-8 h-8" />}
          colorType={stats.profitFactor >= 1.5 ? 'success' : stats.profitFactor >= 1 ? 'default' : 'danger'}
        />
        <MetricCard
          label="Expectancy"
          value={`${stats.expectancy >= 0 ? '+' : ''}$${stats.expectancy.toFixed(2)}`}
          subValue="Per trade average"
          icon={<Zap className="w-8 h-8" />}
          colorType={stats.expectancy >= 0 ? 'success' : 'danger'}
        />
      </div>

      {/* Secondary Stats Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          {
            label: 'Max Drawdown',
            value: `$${maxDrawdown.toFixed(2)}`,
            sub: `${((maxDrawdown / (Number(initialCapital) || 1000)) * 100).toFixed(1)}% of capital`,
            color: maxDrawdown === 0 ? 'text-white/40' : maxDrawdown / (Number(initialCapital) || 1000) > 0.1 ? 'text-danger' : 'text-amber-500',
          },
          {
            label: 'Avg Realized R:R',
            value: `${stats.avgRR >= 0 ? '' : ''}${stats.avgRR.toFixed(2)}R`,
            sub: stats.avgRR >= 1.5 ? 'Above target' : 'Below 1.5R target',
            color: stats.avgRR >= 1.5 ? 'text-success' : stats.avgRR >= 1 ? 'text-amber-500' : 'text-danger',
          },
          {
            label: 'Current Balance',
            value: `$${currentBalance.toFixed(2)}`,
            sub: `Started $${Number(initialCapital).toFixed(0)}`,
            color: currentBalance >= Number(initialCapital) ? 'text-success' : 'text-danger',
          },
          {
            label: 'Open Positions',
            value: todayStats.openTrades.toString(),
            sub: todayStats.openTrades === 0 ? 'All flat' : `${todayStats.openTrades} active`,
            color: todayStats.openTrades > 0 ? 'text-blue-400' : 'text-white/40',
          },
        ].map(s => (
          <div key={s.label} className="bg-slate-900/40 rounded-xl border border-white/5 px-4 py-3">
            <span className="text-[9px] font-black text-white/30 uppercase tracking-widest block mb-1">{s.label}</span>
            <div className={`text-lg font-black font-mono ${s.color}`}>{s.value}</div>
            <span className="text-[9px] text-white/20 font-bold uppercase tracking-wider">{s.sub}</span>
          </div>
        ))}
      </div>

      {/* Today strip */}
      <div className="bg-slate-900/60 rounded-2xl p-4 border border-white/5 flex flex-wrap items-center justify-between gap-4 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-1 h-full bg-primary/40" />
        <div className="flex items-center gap-3">
          <div className="p-2 bg-primary/10 rounded-lg">
            <Activity className="w-4 h-4 text-primary" />
          </div>
          <div>
            <span className="text-[9px] font-black uppercase text-white/30 tracking-widest block">Today</span>
            <div className="text-xs font-black text-white italic">SESSION SUMMARY</div>
          </div>
        </div>
        <div className="flex items-center gap-8 flex-wrap">
          <div className="text-center">
            <span className="text-[8px] font-black text-white/20 uppercase tracking-[0.2em] mb-1 block">Closed</span>
            <div className="text-xl font-black text-white font-mono">{todayStats.totalToday}</div>
          </div>
          <div className="text-center">
            <span className="text-[8px] font-black text-white/20 uppercase tracking-[0.2em] mb-1 block">P&L</span>
            <div className={`text-xl font-black font-mono ${todayStats.pnlToday >= 0 ? 'text-success' : 'text-danger'}`}>
              {todayStats.pnlToday >= 0 ? '+' : ''}${todayStats.pnlToday.toFixed(2)}
            </div>
          </div>
          <div className="text-center">
            <span className="text-[8px] font-black text-white/20 uppercase tracking-[0.2em] mb-1 block">Win Rate</span>
            <div className={`text-xl font-black font-mono ${todayStats.winRateToday >= 50 ? 'text-success' : 'text-amber-500'}`}>
              {todayStats.winRateToday.toFixed(0)}%
            </div>
          </div>
          {todayStats.openTrades > 0 && (
            <div className="text-center">
              <span className="text-[8px] font-black text-white/20 uppercase tracking-[0.2em] mb-1 block">Open</span>
              <div className="text-xl font-black text-blue-400 font-mono animate-pulse">{todayStats.openTrades}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function MetricCard({
  label, value, subValue, icon, colorType = 'default'
}: {
  label: string; value: string; subValue: string; icon: React.ReactNode;
  colorType?: 'default' | 'success' | 'danger';
}) {
  return (
    <div className="bento-card border-white/5 bg-slate-900/40 relative group overflow-hidden hover:bg-slate-900/60 transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_20px_40px_rgba(0,0,0,0.3)]">
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 group-hover:scale-125 transition-all duration-500 text-white">
        {icon}
      </div>
      <div className="relative z-10">
        <span className="text-[9px] font-black text-white/30 uppercase tracking-[0.2em] mb-2 block group-hover:text-primary transition-colors">
          {label}
        </span>
        <div className={cn(
          "text-3xl font-black font-mono tracking-tighter tabular-nums leading-none mb-2",
          colorType === 'success' ? 'text-success' : colorType === 'danger' ? 'text-danger' : 'text-white'
        )}>
          {value}
        </div>
        <span className="text-[9px] font-bold text-white/20 uppercase tracking-widest block group-hover:text-white/30 transition-colors">
          {subValue}
        </span>
      </div>
      <div className="absolute inset-0 bg-gradient-to-br from-white/3 to-transparent pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity" />
    </div>
  );
}
