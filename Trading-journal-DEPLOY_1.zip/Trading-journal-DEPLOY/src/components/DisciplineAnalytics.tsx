import React, { useState, useMemo } from 'react';
import { Trade, TradingSession } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';
import { TrendingUp, AlertOctagon, Trophy, BrainCircuit, Timer, Zap } from 'lucide-react';
import { useEquityCurve } from '../hooks/useEquityCurve';

interface DisciplineAnalyticsProps {
  trades: Trade[];
  initialCapital: number;
}

export function DisciplineAnalytics({ trades, initialCapital }: DisciplineAnalyticsProps) {
  const [selectedWeek, setSelectedWeek] = useState(() => {
    const now = new Date();
    const day = now.getDay();
    const diff = now.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(now.setDate(diff)).toISOString().split('T')[0];
  });

  const closedTrades = useMemo(() => trades.filter(t => t.status === 'CLOSED'), [trades]);
  const { data: equityData, maxDrawdown: calculatedMaxDrawdown, currentBalance } = useEquityCurve(trades, initialCapital);

  const weekOptions = useMemo(() => {
    const options = [];
    const now = new Date();
    for (let i = 0; i < 5; i++) {
      const start = new Date(now);
      const day = start.getDay();
      const diff = start.getDate() - day + (day === 0 ? -6 : 1) - (i * 7);
      const monday = new Date(start.setDate(diff));
      const mondayStr = monday.toISOString().split('T')[0];
      const sunday = new Date(monday);
      sunday.setDate(sunday.getDate() + 6);
      options.push({
        value: mondayStr,
        label: i === 0 ? 'This Week' : `${monday.toLocaleDateString()} - ${sunday.toLocaleDateString()}`,
      });
    }
    return options;
  }, []);

  const stats = useMemo(() => {
    const winners = closedTrades.filter(t => (Number(t.pnl) || 0) > 0);
    const totalPnL = closedTrades.reduce((acc, t) => acc + (Number(t.pnl) || 0), 0);
    const grossProfit = closedTrades.reduce((acc, t) => acc + (Number(t.pnl) > 0 ? Number(t.pnl) : 0), 0);
    const grossLoss = Math.abs(closedTrades.reduce((acc, t) => acc + (Number(t.pnl) < 0 ? Number(t.pnl) : 0), 0) || 1);
    const profitFactor = grossProfit / grossLoss;
    const initialCap = Number(initialCapital) || 1000;

    // Calmar Ratio = Return / Max Drawdown (correctly labelled)
    const calmarRatio = (totalPnL / (calculatedMaxDrawdown || 1)).toFixed(2);

    return {
      profitFactor: profitFactor.toFixed(2),
      avgWin: (winners.reduce((acc, t) => acc + (Number(t.pnl) || 0), 0) / (winners.length || 1)).toFixed(2),
      totalTrades: closedTrades.length,
      totalPnL: totalPnL.toFixed(2),
      currentBalance,
      totalROI: ((totalPnL / initialCap) * 100).toFixed(1),
      maxDrawdown: calculatedMaxDrawdown.toFixed(2),
      calmarRatio,
    };
  }, [closedTrades, initialCapital, currentBalance, calculatedMaxDrawdown]);

  const sessionAnalytics = useMemo(() => {
    const sessions: TradingSession[] = ['LONDON', 'NEW YORK', 'TOKYO', 'SYDNEY', 'INTER-SESSION'];
    return sessions.map(s => {
      const sTrades = closedTrades.filter(t => t.session === s);
      const wins = sTrades.filter(t => (t.pnl || 0) > 0).length;
      const profit = sTrades.reduce((acc, t) => acc + (t.pnl || 0), 0);
      const winRate = sTrades.length > 0 ? (wins / sTrades.length) * 100 : 0;
      return {
        name: s.replace('NEW YORK', 'NY'),
        winRate,
        profit: profit.toFixed(0),
        count: sTrades.length,
        color: profit >= 0 ? '#10b981' : '#f43f5e',
      };
    }).filter(s => s.count > 0);
  }, [closedTrades]);

  const emotionCorrelation = useMemo(() => {
    const buckets = [
      { range: '1-3', label: 'CHAOS/FEAR', trades: closedTrades.filter(t => (t.emotionScore || 5) <= 3) },
      { range: '4-7', label: 'NEUTRAL', trades: closedTrades.filter(t => (t.emotionScore || 5) > 3 && (t.emotionScore || 5) <= 7) },
      { range: '8-10', label: 'ZEN/FLOW', trades: closedTrades.filter(t => (t.emotionScore || 5) > 7) },
    ];
    return buckets.map(b => {
      const wins = b.trades.filter(t => (t.pnl || 0) > 0).length;
      const winRate = b.trades.length > 0 ? (wins / b.trades.length) * 100 : 0;
      return { ...b, winRate };
    });
  }, [closedTrades]);

  const weekStats = useMemo(() => {
    const weekStart = new Date(selectedWeek);
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 7);
    const weekTrades = closedTrades.filter(t => {
      const d = new Date(t.date);
      return d >= weekStart && d < weekEnd;
    });
    const total = weekTrades.length;
    const tpCount = weekTrades.filter(t => t.exitReason === 'TP').length;
    const slCount = weekTrades.filter(t => t.exitReason === 'SL').length;
    const disciplinedCount = tpCount + slCount;
    const discRate = total > 0 ? (disciplinedCount / total) * 100 : 0;
    const totalPnL = weekTrades.reduce((acc, t) => acc + (t.pnl || 0), 0);
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const chartData = days.map((day, idx) => ({
      name: day,
      count: weekTrades.filter(t => new Date(t.date).getDay() === idx).length,
    }));
    return { total, discRate, winRate: total > 0 ? (tpCount / total) * 100 : 0, totalPnL, chartData };
  }, [selectedWeek, closedTrades]);

  const mentorStats = useMemo(() => {
    const mentors = Array.from(new Set(closedTrades.map(t => t.mentor || 'Self')));
    return mentors.map(m => {
      const mTrades = closedTrades.filter(t => (t.mentor || 'Self') === m);
      const profit = mTrades.reduce((acc, t) => acc + (t.pnl || 0), 0);
      const wins = mTrades.filter(t => (t.pnl || 0) > 0).length;
      const winRate = mTrades.length > 0 ? (wins / mTrades.length) * 100 : 0;
      return { name: m, profit: profit.toFixed(2), winRate: winRate.toFixed(0), count: mTrades.length, isPositive: profit >= 0 };
    }).sort((a, b) => parseFloat(b.profit) - parseFloat(a.profit));
  }, [closedTrades]);

  const getZone = () => {
    if (weekStats.total < 3) return { label: 'INSUFFICIENT DATA', type: 'none', message: 'Execute at least 3 trades for audit.' };
    if (weekStats.discRate >= 70) return { label: 'PRO ZONE', type: 'green', message: 'Elite execution. Maintain risk.', reward: 'Permission to scale lot size by 0.01 if win rate > 50%.' };
    if (weekStats.discRate >= 40) return { label: 'RECOVERY ZONE', type: 'yellow', message: 'Process leakage detected.', reward: 'Fixed lot size only. Mandatory demo for next 3 trades.' };
    return { label: 'DANGER ZONE', type: 'red', message: 'Self-sabotage active.', reward: 'TRADING BAN. Review psychology notes immediately.' };
  };

  const zone = getZone();

  return (
    <div className="space-y-6 h-full">
      <div className="flex items-center justify-between">
        <div className="card-title text-[10px] font-black uppercase text-text-dim tracking-[0.2em] flex items-center gap-3">
          <div className="w-1.5 h-1.5 rounded-full bg-primary" />
          Strategic Performance Audit
        </div>
        <select
          value={selectedWeek}
          onChange={e => setSelectedWeek(e.target.value)}
          className="text-[10px] font-bold bg-slate-900 border border-border rounded-lg px-3 py-1.5 text-text-dim focus:outline-none focus:ring-1 focus:ring-primary transition-all hover:border-text-dim/50"
        >
          {weekOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Zone Card */}
        <div className="bento-card group/zone bg-gradient-to-br from-slate-900 to-[#020617] border-primary/20 text-white overflow-hidden relative min-h-[220px]">
          <div className="absolute top-0 right-0 w-48 h-48 bg-primary/10 rounded-full blur-[80px] -mr-12 -mt-12 transition-all duration-700 group-hover/zone:scale-110" />
          <div className="card-title text-[9px] font-black uppercase tracking-[0.3em] text-primary mb-5 opacity-60">Current Status Protocol</div>
          <div className="flex items-baseline gap-3 mb-2">
            <div className={`text-5xl font-black tracking-tighter italic ${
              zone.type === 'green' ? 'text-success drop-shadow-[0_0_15px_rgba(16,185,129,0.3)]' :
              zone.type === 'yellow' ? 'text-accent drop-shadow-[0_0_15px_rgba(245,158,11,0.3)]' :
              zone.type === 'red' ? 'text-danger drop-shadow-[0_0_15px_rgba(244,63,94,0.3)]' : 'text-slate-400'
            }`}>
              {zone.label.split(' ')[0]}
            </div>
            <span className="text-[11px] font-black text-white/20 uppercase tracking-widest">{zone.label.split(' ').slice(1).join(' ')}</span>
          </div>
          <p className="text-[12px] font-medium text-white/50 mb-8 leading-relaxed max-w-[80%]">{zone.message}</p>
          <div className="mt-auto grid grid-cols-2 gap-6 pt-6 border-t border-white/5">
            <div>
              <span className="text-[9px] block text-white/30 uppercase font-black tracking-widest mb-1.5">Net Equity</span>
              <span className="text-2xl font-black text-white font-mono">${stats.currentBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div>
              <span className="text-[9px] block text-white/30 uppercase font-black tracking-widest mb-1.5">Growth ROI</span>
              <span className={`text-2xl font-black font-mono ${parseFloat(stats.totalROI) >= 0 ? 'text-success' : 'text-danger'}`}>
                {parseFloat(stats.totalROI) >= 0 ? '+' : ''}{stats.totalROI}%
              </span>
            </div>
          </div>
        </div>

        {/* Mini Equity Curve */}
        <div className="bento-card bg-slate-900/50 backdrop-blur-md border-border/50 shadow-2xl relative overflow-hidden">
          <div className="flex items-center justify-between mb-6">
            <div className="card-title text-[9px] font-black uppercase text-text-dim tracking-[0.3em]">Trajectory Analysis</div>
            <div className={`text-[10px] font-black font-mono px-3 py-1 rounded-full border ${stats.currentBalance >= initialCapital ? 'bg-success/10 text-success border-success/20' : 'bg-danger/10 text-danger border-danger/20'}`}>
              {stats.currentBalance >= initialCapital ? '+' : '-'}${Math.abs(stats.currentBalance - initialCapital).toFixed(2)} P/L
            </div>
          </div>
          <div className="h-40 w-full">
            {equityData.length < 2 ? (
              <div className="w-full h-full flex items-center justify-center text-[10px] text-text-dim/30 font-black tracking-widest uppercase bg-black/20 rounded-xl border border-dashed border-white/5">
                Awaiting trade data
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={equityData}>
                  <defs>
                    <linearGradient id="miniColorPnL" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="5 5" vertical={false} stroke="#1e293b" strokeOpacity={0.5} />
                  <XAxis dataKey="date" hide />
                  <YAxis hide domain={['auto', 'auto']} />
                  <Tooltip
                    cursor={{ stroke: '#3b82f6', strokeWidth: 1, strokeDasharray: '4 4' }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-slate-900 text-white px-4 py-2 rounded-xl text-[10px] font-bold shadow border border-white/10">
                            <div className="font-mono text-sm">${payload[0].value?.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Area type="monotone" dataKey="balance" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#miniColorPnL)" animationDuration={2000} />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      {/* Signal Source Performance */}
      {mentorStats.length > 0 && (
        <div className="bento-card bg-slate-900/40 border-border/50">
          <div className="card-title text-[9px] font-black uppercase text-primary tracking-[0.3em] mb-6 flex items-center gap-3">
            <Trophy className="w-3 h-3" /> Signal Source Performance
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mentorStats.map(m => (
              <div key={m.name} className="bg-black/30 p-4 rounded-xl border border-border/30 flex items-center justify-between group hover:border-primary/50 transition-all">
                <div className="space-y-1.5">
                  <div className="text-[12px] font-black text-white uppercase tracking-tight">{m.name}</div>
                  <div className="text-[9px] font-bold text-text-dim uppercase flex items-center gap-2">
                    <span className="text-white/40">{m.count} trades</span>
                    <div className="w-0.5 h-0.5 rounded-full bg-slate-600" />
                    <span className={m.isPositive ? 'text-success' : 'text-danger'}>{m.winRate}% WR</span>
                  </div>
                </div>
                <div className={`text-sm font-black font-mono ${m.isPositive ? 'text-success' : 'text-danger'}`}>
                  {m.isPositive ? '+' : ''}{m.profit}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Stats Row — fixed label: Calmar Ratio */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {[
          { label: 'Discipline', val: `${weekStats.discRate.toFixed(0)}%`, sub: 'This Window', color: 'text-primary' },
          { label: 'Net P&L', val: `$${stats.totalPnL}`, sub: 'Cumulative', color: parseFloat(stats.totalPnL) >= 0 ? 'text-success font-mono' : 'text-danger font-mono' },
          { label: 'Max Drawdown', val: `$${stats.maxDrawdown}`, sub: 'Peak to Trough', color: 'text-danger font-mono' },
          { label: 'Calmar Ratio', val: stats.calmarRatio, sub: 'Return / Drawdown', color: parseFloat(stats.calmarRatio) >= 2 ? 'text-success font-mono' : 'text-white font-mono' },
          { label: 'Profit Factor', val: stats.profitFactor, sub: 'Gross Win/Loss', color: parseFloat(stats.profitFactor) >= 1.5 ? 'text-success font-mono' : 'text-white font-mono' },
        ].map(s => (
          <div key={s.label} className="bento-card border-border/30 bg-slate-900/30 backdrop-blur-sm !p-4 hover:translate-y-[-2px] hover:shadow-[0_8px_20px_rgba(0,0,0,0.3)] transition-all">
            <span className="text-[9px] font-black text-white/30 uppercase tracking-[0.2em] mb-2 block">{s.label}</span>
            <div className={`text-2xl font-black ${s.color}`}>{s.val}</div>
            <span className="text-[8px] font-bold text-text-dim uppercase tracking-wider mt-1 block">{s.sub}</span>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Session Bar Chart */}
        <div className="bento-card bg-slate-900/40 border-border/30 col-span-1 md:col-span-2">
          <div className="flex items-center justify-between mb-8">
            <div className="card-title text-[9px] font-black uppercase text-primary tracking-[0.3em] flex items-center gap-3">
              <Timer className="w-3.5 h-3.5" /> Session Dominance
            </div>
            <div className="text-[9px] font-bold text-text-dim uppercase">Win Rate by Market Session</div>
          </div>
          <div className="h-48 w-full">
            {sessionAnalytics.length === 0 ? (
              <div className="w-full h-full flex items-center justify-center text-[10px] text-text-dim/20 font-black uppercase italic">No session data yet</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={sessionAnalytics}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ffffff05" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#ffffff40', fontSize: 10, fontWeight: 900 }} />
                  <YAxis hide domain={[0, 100]} />
                  <Tooltip
                    cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        return (
                          <div className="bg-slate-900 border border-white/10 p-4 rounded-xl shadow-2xl">
                            <span className="text-[8px] font-black text-white/30 uppercase tracking-widest block mb-2">{d.name} SESSION</span>
                            <div className="text-2xl font-black text-success font-mono">{d.winRate.toFixed(0)}%</div>
                            <div className="text-[10px] font-bold text-white/60 mt-1 uppercase">${d.profit} Net P/L · {d.count} trades</div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="winRate" radius={[4, 4, 0, 0]}>
                    {sessionAnalytics.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} fillOpacity={0.6} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Emotion Intelligence */}
        <div className="bento-card bg-slate-900/40 border-border/30">
          <div className="card-title text-[9px] font-black uppercase text-primary tracking-[0.3em] mb-8 flex items-center gap-3">
            <BrainCircuit className="w-3.5 h-3.5" /> Mind-State Impact
          </div>
          <div className="space-y-5">
            {emotionCorrelation.map(e => (
              <div key={e.range} className="space-y-2">
                <div className="flex justify-between items-end">
                  <span className="text-[10px] font-black text-white/60 uppercase tracking-tighter">{e.label}</span>
                  <span className="text-[10px] font-black font-mono text-primary">{e.winRate.toFixed(0)}% WR</span>
                </div>
                <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-primary to-blue-400 transition-all duration-1000"
                    style={{ width: `${e.winRate}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-8 p-3 bg-white/5 rounded-xl border border-white/5">
            <p className="text-[10px] font-bold text-text-dim leading-tight italic">
              {(() => {
                const best = [...emotionCorrelation].sort((a, b) => b.winRate - a.winRate)[0];
                return best?.winRate > 0
                  ? `Your edge is maximal during ${best.label} states.`
                  : 'Calibrating emotional response patterns...';
              })()}
            </p>
          </div>
        </div>
      </div>

      {zone.reward && (
        <div className="bento-card !p-4 bg-slate-900 border-dashed border-primary/30 flex flex-row items-center gap-4">
          <div className={`p-2 rounded-xl scale-110 ${zone.type === 'green' ? 'bg-success/10 text-success shadow-[0_0_15px_rgba(16,185,129,0.2)]' : 'bg-amber-500/10 text-amber-500'}`}>
            {zone.type === 'green' ? <Trophy className="w-5 h-5" /> : <AlertOctagon className="w-5 h-5" />}
          </div>
          <div className="leading-tight">
            <span className="text-[9px] font-black uppercase text-text-dim tracking-[0.3em] block opacity-40 mb-1">Coach Directive</span>
            <p className="text-[12px] font-bold text-white leading-tight italic">{zone.reward}</p>
          </div>
        </div>
      )}
    </div>
  );
}
