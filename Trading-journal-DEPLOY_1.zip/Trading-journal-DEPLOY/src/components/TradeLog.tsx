import React, { useState, useMemo } from 'react';
import { Trade } from '../types';
import { formatDateTime, cn, calcRealizedRR } from '../lib/utils';
import { Filter, TrendingUp, LayoutGrid, List, Pencil, Trash2 } from 'lucide-react';
import { TradeCard } from './TradeCard';

interface TradeLogProps {
  trades: Trade[];
  onEndTrade: (trade: Trade) => void;
  onDelete: (id: string) => void;
  onEdit: (trade: Trade) => void;
}

export function TradeLog({ trades, onEndTrade, onDelete, onEdit }: TradeLogProps) {
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'WINS' | 'LOSSES'>('ALL');
  const [dateFilter, setDateFilter] = useState<'TODAY' | 'THIS_WEEK' | 'THIS_MONTH' | 'ALL'>('ALL');
  const [setupFilter, setSetupFilter] = useState<string>('ALL');
  const [sessionFilter, setSessionFilter] = useState<string>('ALL');
  const [viewMode, setViewMode] = useState<'card' | 'table'>('card');

  const filteredTrades = useMemo(() => {
    return trades.filter(t => {
      const tradeDate = new Date(t.date);
      const now = new Date();
      let passDate = true;
      if (dateFilter === 'TODAY') {
        passDate = tradeDate.toDateString() === now.toDateString();
      } else if (dateFilter === 'THIS_WEEK') {
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - now.getDay());
        passDate = tradeDate >= weekStart;
      } else if (dateFilter === 'THIS_MONTH') {
        passDate = tradeDate.getMonth() === now.getMonth() && tradeDate.getFullYear() === now.getFullYear();
      }
      const pnl = t.pnl || 0;
      const passStatus = statusFilter === 'ALL' ? true : statusFilter === 'WINS' ? (t.status === 'CLOSED' && pnl > 0) : (t.status === 'CLOSED' && pnl < 0);
      const passSetup = setupFilter === 'ALL' ? true : t.setup === setupFilter;
      const passSession = sessionFilter === 'ALL' ? true : t.marketSession === sessionFilter;
      return passDate && passStatus && passSetup && passSession;
    });
  }, [trades, statusFilter, dateFilter, setupFilter, sessionFilter]);

  const sortedTrades = [...filteredTrades].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-8">
      {/* Header + Filters */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="card-title text-[10px] font-black uppercase text-white/40 tracking-[0.4em] flex items-center gap-3">
          <div className="w-1.5 h-4 bg-primary rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)]" />
          Trade Journal — {sortedTrades.length} record{sortedTrades.length !== 1 ? 's' : ''}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* View toggle */}
          <div className="flex items-center gap-1 bg-slate-900/60 border border-white/5 p-1 rounded-xl">
            <button
              onClick={() => setViewMode('card')}
              className={cn("p-1.5 rounded-lg transition-all", viewMode === 'card' ? "bg-primary text-white" : "text-white/20 hover:text-white/60")}
              title="Card view"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={cn("p-1.5 rounded-lg transition-all", viewMode === 'table' ? "bg-primary text-white" : "text-white/20 hover:text-white/60")}
              title="Table view"
            >
              <List className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Status filter */}
          <div className="flex items-center gap-2 bg-slate-900/60 border border-white/5 p-1 rounded-2xl">
            {(['ALL', 'WINS', 'LOSSES'] as const).map(s => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={cn("px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all", statusFilter === s ? "bg-primary text-white shadow-lg" : "text-white/20 hover:text-white/60")}
              >
                {s}
              </button>
            ))}
          </div>

          {/* Additional filters */}
          <div className="flex bg-slate-900/60 border border-white/5 p-1 rounded-2xl gap-2 items-center px-4">
            <Filter className="w-3 h-3 text-white/20" />
            <select value={setupFilter} onChange={e => setSetupFilter(e.target.value)} className="bg-transparent text-[10px] font-black text-white/40 focus:outline-none uppercase tracking-widest cursor-pointer hover:text-white transition-colors">
              <option value="ALL">All Setups</option>
              <option value="FVG">FVG</option>
              <option value="OB">Order Block</option>
              <option value="BREAKOUT">Breakout</option>
              <option value="SCALPING">Scalping</option>
            </select>
            <div className="w-[1px] h-3 bg-white/5" />
            <select value={dateFilter} onChange={e => setDateFilter(e.target.value as any)} className="bg-transparent text-[10px] font-black text-white/40 focus:outline-none uppercase tracking-widest cursor-pointer hover:text-white transition-colors">
              <option value="ALL">All Time</option>
              <option value="TODAY">Today</option>
              <option value="THIS_WEEK">This Week</option>
              <option value="THIS_MONTH">This Month</option>
            </select>
            <div className="w-[1px] h-3 bg-white/5" />
            <select value={sessionFilter} onChange={e => setSessionFilter(e.target.value)} className="bg-transparent text-[10px] font-black text-white/40 focus:outline-none uppercase tracking-widest cursor-pointer hover:text-white transition-colors">
              <option value="ALL">All Sessions</option>
              <option value="ASIA">Asia</option>
              <option value="LONDON">London</option>
              <option value="NEW YORK">New York</option>
            </select>
          </div>
        </div>
      </div>

      {/* Empty state */}
      {sortedTrades.length === 0 && (
        <div className="py-32 text-center border-2 border-dashed border-white/5 rounded-[3rem] bg-slate-950/40">
          <div className="w-20 h-20 bg-white/5 rounded-[2rem] flex items-center justify-center mx-auto mb-8 ring-1 ring-white/10">
            <TrendingUp className="w-10 h-10 text-white/10" />
          </div>
          <p className="text-sm font-black text-white/30 uppercase tracking-[0.5em] mb-3">No Trades Found</p>
          <p className="text-[10px] font-bold text-white/10 uppercase tracking-[0.2em] max-w-xs mx-auto leading-relaxed">
            {trades.length === 0 ? 'Start logging trades to see them here.' : 'No trades match the current filters.'}
          </p>
        </div>
      )}

      {/* Card View */}
      {viewMode === 'card' && sortedTrades.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-start">
          {sortedTrades.map(trade => (
            <TradeCard key={trade.id} trade={trade} onEndTrade={onEndTrade} onDelete={onDelete} onEdit={onEdit} />
          ))}
        </div>
      )}

      {/* Table View */}
      {viewMode === 'table' && sortedTrades.length > 0 && (
        <div className="table-scroll">
          <table className="w-full text-[11px] font-mono">
            <thead>
              <tr className="bg-slate-900/80 border-b border-white/5">
                {['Date', 'Pair', 'Dir', 'Entry', 'Exit', 'SL', 'TP', 'Lots', 'R:R', 'P&L', 'Setup', 'Exit', 'Actions'].map(h => (
                  <th key={h} className="px-3 py-3 text-left text-[9px] font-black uppercase tracking-widest text-white/30 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sortedTrades.map((trade, i) => {
                const rr = calcRealizedRR(trade);
                const rrDisplay = trade.status === 'CLOSED' && trade.exitPrice
                  ? (rr >= 0 ? '+' : '') + rr.toFixed(1) + 'R'
                  : (() => {
                      const risk = Math.abs(trade.entryPrice - trade.slPrice);
                      const planned = Math.abs(trade.tpPrice - trade.entryPrice);
                      return risk > 0 ? (planned / risk).toFixed(1) + 'R' : '—';
                    })();
                return (
                  <tr key={trade.id} className={cn("border-b border-white/5 hover:bg-white/2 transition-colors", i % 2 === 0 ? 'bg-slate-900/20' : 'bg-transparent')}>
                    <td className="px-3 py-2.5 text-white/40 whitespace-nowrap">{new Date(trade.date).toLocaleDateString([], { month: 'short', day: '2-digit' })} {new Date(trade.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</td>
                    <td className="px-3 py-2.5 font-black text-white whitespace-nowrap">{trade.pair === 'Other' && trade.customPair ? trade.customPair : trade.pair}</td>
                    <td className="px-3 py-2.5">
                      <span className={cn("px-2 py-0.5 rounded text-[9px] font-black uppercase", trade.direction === 'BUY' ? 'bg-success/10 text-success' : 'bg-danger/10 text-danger')}>
                        {trade.direction}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-white/70">{trade.entryPrice.toFixed(2)}</td>
                    <td className="px-3 py-2.5 text-white/70">{trade.exitPrice ? trade.exitPrice.toFixed(2) : <span className="text-blue-400 animate-pulse text-[9px]">OPEN</span>}</td>
                    <td className="px-3 py-2.5 text-danger/70">{trade.slPrice.toFixed(2)}</td>
                    <td className="px-3 py-2.5 text-success/70">{trade.tpPrice.toFixed(2)}</td>
                    <td className="px-3 py-2.5 text-white/50">{trade.lotSize}</td>
                    <td className={cn("px-3 py-2.5 font-black", trade.status === 'CLOSED' ? (rr >= 0 ? 'text-success' : 'text-danger') : 'text-primary')}>
                      {rrDisplay}
                    </td>
                    <td className={cn("px-3 py-2.5 font-black", trade.pnl === undefined ? 'text-white/30' : trade.pnl >= 0 ? 'text-success' : 'text-danger')}>
                      {trade.pnl !== undefined ? (trade.pnl >= 0 ? '+' : '') + trade.pnl.toFixed(2) : '—'}
                    </td>
                    <td className="px-3 py-2.5 text-white/40">{trade.setup || '—'}</td>
                    <td className="px-3 py-2.5">
                      {trade.exitReason ? (
                        <span className={cn("px-2 py-0.5 rounded text-[9px] font-black uppercase",
                          trade.exitReason === 'TP' ? 'bg-success/10 text-success' :
                          trade.exitReason === 'SL' ? 'bg-danger/10 text-danger' :
                          'bg-amber-500/10 text-amber-500'
                        )}>
                          {trade.exitReason}
                        </span>
                      ) : <span className="text-white/20">—</span>}
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-1">
                        {trade.status === 'OPEN' ? (
                          <button onClick={() => onEndTrade(trade)} className="px-2.5 py-1 bg-primary/20 hover:bg-primary text-primary hover:text-white text-[9px] font-black uppercase rounded-lg transition-all whitespace-nowrap">
                            Close
                          </button>
                        ) : (
                          <>
                            <button onClick={() => onEdit(trade)} className="p-1.5 text-white/20 hover:text-primary hover:bg-primary/10 rounded-lg transition-all" title="Edit">
                              <Pencil className="w-3 h-3" />
                            </button>
                            <button onClick={() => { if (window.confirm('Delete this trade?')) onDelete(trade.id); }} className="p-1.5 text-white/20 hover:text-danger hover:bg-danger/10 rounded-lg transition-all" title="Delete">
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
