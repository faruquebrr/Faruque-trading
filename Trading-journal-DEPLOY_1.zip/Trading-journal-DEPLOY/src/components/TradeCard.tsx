import React from 'react';
import { Trade } from '../types';
import { formatDateTime, cn, calculatePotentialRisk, calculatePotentialReward } from '../lib/utils';
import { TrendingUp, Trash2, Clock, CheckCircle2, XCircle, AlertCircle, Pencil } from 'lucide-react';

interface TradeCardProps {
  trade: Trade;
  onEndTrade: (trade: Trade) => void;
  onDelete: (id: string) => void;
  onEdit?: (trade: Trade) => void;
  key?: React.Key;
}

export function TradeCard({ trade, onEndTrade, onDelete, onEdit }: TradeCardProps) {
  const getStatusBadge = () => {
    if (trade.status === 'OPEN') {
      return (
        <span className="inline-flex items-center gap-1.5 text-blue-400 bg-blue-500/10 px-2.5 py-1 rounded-full text-[10px] font-black uppercase border border-blue-500/20 shadow-[0_0_10px_rgba(59,130,246,0.1)]">
          <Clock className="w-3 h-3 animate-pulse" /> OPEN
        </span>
      );
    }
    if (trade.exitReason === 'TP') {
      return (
        <span className="inline-flex items-center gap-1.5 text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full text-[10px] font-black uppercase border border-emerald-500/20">
          <CheckCircle2 className="w-3 h-3" /> TP HIT
        </span>
      );
    }
    if (trade.exitReason === 'SL') {
      return (
        <span className="inline-flex items-center gap-1.5 text-rose-400 bg-rose-500/10 px-2.5 py-1 rounded-full text-[10px] font-black uppercase border border-rose-500/20">
          <XCircle className="w-3 h-3" /> SL HIT
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-full text-[10px] font-black uppercase border border-amber-500/20">
        <AlertCircle className="w-3 h-3" /> {trade.exitReason || 'CLOSED'}
      </span>
    );
  };

  const { rrValue, rrLabel } = (() => {
    const risk = Math.abs(trade.entryPrice - trade.slPrice);
    if (risk === 0) return { rrValue: '0', rrLabel: 'R:R' };
    if (trade.status === 'CLOSED' && trade.exitPrice) {
      const realized = trade.direction === 'BUY'
        ? trade.exitPrice - trade.entryPrice
        : trade.entryPrice - trade.exitPrice;
      return { rrValue: (realized / risk).toFixed(1), rrLabel: 'Realized R:R' };
    }
    const planned = Math.abs(trade.tpPrice - trade.entryPrice);
    return { rrValue: (planned / risk).toFixed(1), rrLabel: 'Planned R:R' };
  })();

  return (
    <div className="bento-card !p-0 bg-slate-900/40 border-white/5 group hover:border-primary/30 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl overflow-hidden relative">
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity" />

      <div className="p-5 space-y-5 relative z-10">
        {/* TOP ROW */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={cn(
              "w-10 h-10 rounded-xl flex items-center justify-center border",
              trade.direction === 'BUY' ? "bg-success/5 border-success/20 text-success" : "bg-danger/5 border-danger/20 text-danger"
            )}>
              <TrendingUp className={cn("w-5 h-5", trade.direction === 'SELL' && "rotate-180")} />
            </div>
            <div>
              <div className="text-base font-black text-white leading-none">
                {trade.pair === 'Other' && trade.customPair ? trade.customPair : trade.pair}
              </div>
              <div className="text-[10px] font-bold text-white/20 mt-1 uppercase tracking-widest">{formatDateTime(trade.date)}</div>
            </div>
          </div>

          <div className="text-right">
            <div className="mb-1">{getStatusBadge()}</div>
            {trade.status === 'CLOSED' ? (
              <div className={cn(
                "text-4xl font-black font-mono tracking-tighter tabular-nums leading-none",
                trade.pnl! >= 0 ? "text-success drop-shadow-[0_0_15px_rgba(16,185,129,0.3)]" : "text-danger drop-shadow-[0_0_15px_rgba(244,63,94,0.3)]"
              )}>
                {trade.pnl! >= 0 ? '+' : ''}{trade.pnl!.toFixed(2)}
              </div>
            ) : (
              <div className="flex flex-col items-end">
                <div className="text-xl font-black text-blue-400 animate-pulse font-mono tracking-tighter leading-none mb-1 italic">EXECUTING</div>
                <div className="flex items-center gap-1.5 opacity-40 justify-end">
                  <div className="flex items-center gap-1">
                    <div className="w-1 h-1 rounded-full bg-danger/50" />
                    <span className="text-[7px] font-black text-white uppercase tracking-widest whitespace-nowrap">
                      Risk -${calculatePotentialRisk(trade.entryPrice, trade.slPrice, trade.lotSize, trade.pair, trade.customPair).toFixed(2)}
                    </span>
                  </div>
                  <div className="w-[1px] h-2 bg-white/10" />
                  <div className="flex items-center gap-1">
                    <div className="w-1 h-1 rounded-full bg-success/50" />
                    <span className="text-[7px] font-black text-white uppercase tracking-widest whitespace-nowrap">
                      Goal +${calculatePotentialReward(trade.entryPrice, trade.tpPrice, trade.lotSize, trade.pair, trade.customPair).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* BADGES ROW */}
        <div className="flex flex-wrap gap-2">
          {trade.setup && (
            <span className="px-2 py-0.5 rounded-md bg-primary/10 border border-primary/20 text-[8px] font-black text-primary uppercase tracking-[0.2em]">
              {trade.setup}
            </span>
          )}
          {trade.marketSession && (
            <span className="px-2 py-0.5 rounded-md bg-amber-500/10 border border-amber-500/20 text-[8px] font-black text-amber-500 uppercase tracking-[0.2em]">
              {trade.marketSession}
            </span>
          )}
          {trade.preEmotion && (
            <span className="px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-[8px] font-black text-white/40 uppercase tracking-[0.2em]">
              {trade.preEmotion}
            </span>
          )}
        </div>

        {/* PRICE ROW */}
        <div className="grid grid-cols-3 gap-2 py-4 border-y border-white/5 bg-black/20 -mx-5 px-5">
          <div className="text-center">
            <div className="text-[8px] font-black text-white/20 uppercase tracking-widest mb-1">Entry</div>
            <div className="text-xs font-black text-white font-mono">${trade.entryPrice.toFixed(2)}</div>
          </div>
          <div className="text-center border-l border-white/5">
            <div className="text-[8px] font-black text-danger/40 uppercase tracking-widest mb-1">Stop Loss</div>
            <div className="text-xs font-black text-danger font-mono">${trade.slPrice.toFixed(2)}</div>
          </div>
          <div className="text-center border-l border-white/5">
            <div className="text-[8px] font-black text-success/40 uppercase tracking-widest mb-1">Take Profit</div>
            <div className="text-xs font-black text-success font-mono">${trade.tpPrice.toFixed(2)}</div>
          </div>
        </div>

        {/* ACTIONS ROW */}
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">{rrLabel}</span>
            <span className={cn(
              "text-sm font-black font-mono tracking-tighter",
              trade.status === 'CLOSED'
                ? parseFloat(rrValue) >= 0 ? 'text-success' : 'text-danger'
                : 'text-primary'
            )}>
              {trade.status === 'CLOSED' && parseFloat(rrValue) >= 0 ? '+' : ''}{rrValue}R
            </span>
          </div>

          <div className="flex gap-2">
            {trade.status === 'OPEN' ? (
              <button
                onClick={() => onEndTrade(trade)}
                className="bg-primary hover:bg-primary/80 text-white text-[9px] font-black uppercase px-4 py-2 rounded-xl transition-all shadow-[0_0_15px_rgba(59,130,246,0.3)] hover:scale-105 active:scale-95"
              >
                Close Trade
              </button>
            ) : (
              <div className="flex items-center gap-1">
                {onEdit && (
                  <button
                    onClick={() => onEdit(trade)}
                    className="p-2 text-white/20 hover:text-primary hover:bg-primary/10 rounded-xl transition-all"
                    title="Edit Trade"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={() => { if (window.confirm('Delete this trade? This cannot be undone.')) onDelete(trade.id); }}
                  className="p-2 text-white/20 hover:text-danger hover:bg-danger/10 rounded-xl transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
