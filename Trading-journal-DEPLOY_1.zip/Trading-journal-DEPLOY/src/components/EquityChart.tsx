import React, { useMemo } from 'react';
import { Trade } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp } from 'lucide-react';
import { useEquityCurve } from '../hooks/useEquityCurve';

interface EquityChartProps {
  trades: Trade[];
  initialCapital: number;
}

export function EquityChart({ trades, initialCapital }: EquityChartProps) {
  const { data: equityData, maxDrawdown, currentBalance } = useEquityCurve(trades, initialCapital);

  if (equityData.length < 2) {
    return (
      <div className="bento-card bg-slate-900 border-white/5 h-[400px] flex flex-col items-center justify-center gap-4 opacity-50 overflow-hidden relative">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(255,255,255,0.03),transparent_70%)]" />
        <TrendingUp className="w-12 h-12 text-white/10 relative z-10" />
        <div className="text-center relative z-10">
          <p className="text-[10px] font-black uppercase tracking-widest text-white/40 leading-none">Equity Stream Awaiting Data</p>
          <p className="text-[9px] text-white/20 mt-3 max-w-xs mx-auto">Trajectory mapping requires at least one closed trade to initiate the performance curve.</p>
        </div>
      </div>
    );
  }

  const maxDrawdownPercent = ((maxDrawdown / (Number(initialCapital) || 1000)) * 100).toFixed(2);

  return (
    <div className="bento-card !p-0 bg-slate-900 border-white/5 relative overflow-hidden h-[400px] group">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(59,130,246,0.1),transparent_70%)] pointer-events-none" />
      
      {/* Chart Header */}
      <div className="p-6 pb-0 flex items-center justify-between relative z-10">
        <div>
           <div className="flex items-center gap-2 mb-1">
             <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
             <div className="card-title text-[10px] font-black uppercase text-primary tracking-[0.4em]">
               Equity Intelligence Stream
             </div>
           </div>
           <div className="text-[9px] font-black text-white/20 uppercase tracking-widest flex items-center gap-4">
             <span>Real-time Portfolio Value Trajectory</span>
             <span className="text-danger flex items-center gap-1.5 opacity-60">
               <div className="w-1 h-1 rounded-full bg-danger" />
               Max Risk Drawdown: ${maxDrawdown.toFixed(2)} ({maxDrawdownPercent}%)
             </span>
           </div>
        </div>
        <div className="flex items-center gap-8">
           <div className="text-right">
              <span className="text-[8px] font-black text-white/20 uppercase tracking-widest block">Net Liquidity</span>
              <span className="text-2xl font-black text-white font-mono tracking-tighter tabular-nums">
                ${currentBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
           </div>
           <div className="p-3 bg-primary/10 rounded-2xl border border-primary/20 group-hover:scale-110 transition-transform duration-500">
              <TrendingUp className="w-5 h-5 text-primary" />
           </div>
        </div>
      </div>
      
      <div className="absolute inset-x-0 bottom-0 h-[300px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={equityData} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="equityGradientHero" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="drawdownGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.15}/>
                <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="10 10" vertical={false} stroke="rgba(255,255,255,0.02)" />
            <XAxis 
              dataKey="name" 
              hide
            />
            <YAxis 
              domain={['auto', 'auto']}
              hide
            />
            <Tooltip 
              cursor={{ stroke: '#3b82f6', strokeWidth: 1.5, strokeDasharray: '4 4' }}
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  const currentDD = data.peak - data.balance;
                  return (
                    <div className="bg-slate-950/90 backdrop-blur-xl border border-white/10 p-4 rounded-2xl shadow-2xl ring-1 ring-white/10">
                      <div className="flex items-center gap-3 mb-2 pb-2 border-b border-white/5">
                        <div className="p-1.5 bg-primary/20 rounded-lg">
                          <TrendingUp className="w-3 h-3 text-primary" />
                        </div>
                        <div>
                          <span className="text-[8px] font-black text-white/30 uppercase tracking-[0.2em] block leading-none mb-0.5">Point History</span>
                          <span className="text-[10px] font-black text-white uppercase tracking-widest">Trade #{data.name}</span>
                        </div>
                      </div>
                      <div className="text-xl font-black text-white font-mono leading-none flex items-baseline gap-1 mb-2">
                        <span className="text-xs text-white/40">$</span>
                        {data.balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </div>
                      {currentDD > 0 && (
                        <div className="text-[9px] font-black text-danger uppercase tracking-widest bg-danger/10 px-2 py-1 rounded-md border border-danger/10">
                           Drawdown: -${currentDD.toFixed(2)}
                        </div>
                      )}
                    </div>
                  );
                }
                return null;
              }}
            />
            {/* Drawdown Area (Shading between Peak and Balance) */}
            <Area 
              type="monotone" 
              dataKey="peak" 
              stroke="transparent"
              fill="url(#drawdownGradient)"
              animationDuration={2500}
            />
            <Area 
              type="monotone" 
              dataKey="balance" 
              stroke="#3b82f6" 
              strokeWidth={4} 
              fillOpacity={1} 
              fill="url(#equityGradientHero)" 
              animationDuration={2500}
              activeDot={{ r: 6, fill: '#3b82f6', stroke: '#fff', strokeWidth: 2, shadow: '0 0 10px rgba(59,130,246,0.5)' }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
