import React, { useEffect, useRef } from 'react';
import { Activity } from 'lucide-react';

const SYMBOLS = [
  { symbol: 'OANDA:XAUUSD', label: 'XAUUSD' },
  { symbol: 'OANDA:XAGUSD', label: 'XAGUSD' },
  { symbol: 'BINANCE:BTCUSDT', label: 'BTCUSD' },
  { symbol: 'FX:EURUSD', label: 'EURUSD' },
];

function TickerWidget({ symbol }: { symbol: string }) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    // Avoid duplicate injection
    if (el.querySelector('script')) return;
    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-single-quote.js';
    script.type = 'text/javascript';
    script.async = true;
    script.innerHTML = JSON.stringify({
      symbol,
      width: '100%',
      colorTheme: 'dark',
      isTransparent: true,
      locale: 'en',
      largeChartUrl: '',
    });
    el.appendChild(script);
    return () => {
      // cleanup on unmount
      if (el) el.innerHTML = '<div class="tradingview-widget-container__widget"></div>';
    };
  }, [symbol]);

  return (
    <div ref={containerRef} className="tradingview-widget-container w-full">
      <div className="tradingview-widget-container__widget" />
    </div>
  );
}

export function MarketTicker() {
  return (
    <div className="bento-card !p-0 overflow-hidden bg-slate-900 border-border/50 ring-1 ring-white/5">
      {/* Header */}
      <div className="px-4 py-3 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Activity className="w-4 h-4 text-primary animate-pulse" />
          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-text-dim">Live Market Feed</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-success animate-ping" />
          <span className="text-[9px] font-black text-success uppercase tracking-wider">Live</span>
        </div>
      </div>

      {/* Ticker grid — 2×2 on md, 4 columns on xl */}
      <div className="grid grid-cols-2 xl:grid-cols-4 divide-x divide-y divide-white/5 bg-slate-950/30">
        {SYMBOLS.map(({ symbol, label }) => (
          <div key={symbol} className="relative overflow-hidden hover:bg-white/2 transition-colors">
            <div className="absolute top-2 left-3 text-[8px] font-black text-white/20 uppercase tracking-widest z-10 pointer-events-none">
              {label}
            </div>
            <div className="scale-[0.88] origin-top -translate-y-1">
              <TickerWidget symbol={symbol} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
