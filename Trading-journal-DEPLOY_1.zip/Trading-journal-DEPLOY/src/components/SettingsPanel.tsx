import React, { useState, useEffect } from 'react';
import { Settings } from '../types';
import { Settings as SettingsIcon, Download, Trash2, Save, Upload } from 'lucide-react';

interface SettingsPanelProps {
  settings: Settings;
  onUpdate: (settings: Settings) => void;
  onExport: () => void;
  onReset: () => void;
  onImport: (trades: any[], overwrite: boolean) => void;
}

export function SettingsPanel({ settings, onUpdate, onExport, onReset, onImport }: SettingsPanelProps) {
  const [lotSize, setLotSize] = useState(settings.defaultLotSize.toString());
  const [goldLot, setGoldLot] = useState((settings.defaultLots?.['XAUUSD'] || 0.03).toString());
  const [btcLot, setBtcLot] = useState((settings.defaultLots?.['BTCUSD'] || 0.10).toString());
  const [maxRisk, setMaxRisk] = useState(settings.maxDailyRisk.toString());
  const [capital, setCapital] = useState((settings.initialCapital || 1000).toString());
  const [showSaved, setShowSaved] = useState(false);

  useEffect(() => {
    setCapital(settings.initialCapital.toString());
    setLotSize(settings.defaultLotSize.toString());
    setGoldLot((settings.defaultLots?.['XAUUSD'] || 0.03).toString());
    setBtcLot((settings.defaultLots?.['BTCUSD'] || 0.10).toString());
    setMaxRisk(settings.maxDailyRisk.toString());
  }, [settings]);

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = event => {
      try {
        const trades = JSON.parse(event.target?.result as string);
        if (!Array.isArray(trades)) throw new Error('Invalid format');
        const mode = window.confirm(
          'Import Decision:\n\nOK = REPLACE all existing trades with this backup.\nCANCEL = MERGE this backup with current trades.'
        ) ? 'replace' : 'merge';
        onImport(trades, mode === 'replace');
        alert(`Success: ${trades.length} trades ${mode}d.`);
      } catch {
        alert('Error: Could not parse the import file. Make sure it is a valid JSON backup.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleSave = () => {
    onUpdate({
      defaultLotSize: parseFloat(lotSize),
      defaultLots: {
        ...settings.defaultLots,
        'XAUUSD': parseFloat(goldLot),
        'BTCUSD': parseFloat(btcLot),
      },
      maxDailyRisk: parseFloat(maxRisk),
      initialCapital: parseFloat(capital),
    });
    setShowSaved(true);
    setTimeout(() => setShowSaved(false), 2000);
  };

  return (
    <div className="bento-card border-border/30 bg-slate-900/30 backdrop-blur-sm">
      <div className="card-title text-[10px] font-black uppercase text-text-dim tracking-[0.2em] mb-8 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <SettingsIcon className="w-4 h-4 text-primary" />
          Settings
        </div>
        {showSaved && (
          <span className="text-[9px] font-black text-success">Saved ✓</span>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <div className="space-y-2">
          <label className="bento-label !text-white/40">Starting Capital ($)</label>
          <input type="number" value={capital} onChange={e => setCapital(e.target.value)} className="bento-input font-mono font-bold" />
        </div>
        <div className="space-y-2">
          <label className="bento-label !text-white/40">Default Lot Size</label>
          <input type="number" step="0.001" value={lotSize} onChange={e => setLotSize(e.target.value)} className="bento-input font-mono" />
        </div>
        <div className="space-y-2">
          <label className="bento-label text-amber-500/60">XAUUSD Lot</label>
          <input type="number" step="0.001" value={goldLot} onChange={e => setGoldLot(e.target.value)} className="bento-input border-amber-500/20 bg-amber-500/5 font-mono text-amber-500" />
        </div>
        <div className="space-y-2">
          <label className="bento-label text-orange-500/60">BTCUSD Lot</label>
          <input type="number" step="0.001" value={btcLot} onChange={e => setBtcLot(e.target.value)} className="bento-input border-orange-500/20 bg-orange-500/5 font-mono text-orange-500" />
        </div>
        <div className="space-y-2">
          <label className="bento-label !text-white/40">Daily Loss Limit ($)</label>
          <input type="number" value={maxRisk} onChange={e => setMaxRisk(e.target.value)} className="bento-input font-mono" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-8 pt-8 border-t border-white/5">
        <button onClick={handleSave} className="bento-button bg-primary/20 text-primary border border-primary/30 hover:bg-primary hover:text-white">
          <Save className="w-4 h-4 inline mr-2" /> Save Settings
        </button>

        <div className="relative">
          <input type="file" id="trade-import" className="hidden" accept=".json" onChange={handleImport} />
          <button onClick={() => document.getElementById('trade-import')?.click()} className="bento-button w-full bg-slate-800 border border-white/5 text-white/80 hover:bg-slate-700">
            <Upload className="w-4 h-4 inline mr-2" /> Import Backup
          </button>
        </div>

        <button onClick={onExport} className="bento-button bg-slate-800 border border-white/5 text-white/80 hover:bg-slate-700">
          <Download className="w-4 h-4 inline mr-2" /> Export Backup
        </button>

        <button
          onClick={onReset}
          className="bento-button bg-danger/10 text-danger border border-danger/20 hover:bg-danger hover:text-white"
          title="Permanently delete all trade records"
        >
          <Trash2 className="w-4 h-4 inline mr-2" /> Delete All Trades
        </button>
      </div>
    </div>
  );
}
