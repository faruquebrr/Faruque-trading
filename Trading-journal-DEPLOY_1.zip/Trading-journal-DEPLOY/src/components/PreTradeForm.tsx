import React, { useState, useEffect } from 'react';
import { Settings, Trade, AssetPair, Direction, SetupType, MarketSession, EntryEmotion } from '../types';
import { calculatePotentialRisk, calculatePotentialReward, cn } from '../lib/utils';
import { Target, Shield, Zap, Info, Lock } from 'lucide-react';

interface PreTradeFormProps {
  onExecute: (trade: Trade) => void;
  settings: Settings;
}

const CONFLUENCES = [
  { id: 'Trend', label: 'Trend Alignment' },
  { id: 'SR', label: 'Key S/R Level' },
  { id: 'PA', label: 'Price Action Signal' },
  { id: 'Session', label: 'Session Timing' },
];

export function PreTradeForm({ onExecute, settings }: PreTradeFormProps) {
  const [date, setDate] = useState('');
  const [pair, setPair] = useState<AssetPair>('XAUUSD');
  const [customPair, setCustomPair] = useState('');
  const [direction, setDirection] = useState<Direction>('BUY');
  const [setup, setSetup] = useState<SetupType>('SCALPING');
  const [marketSession, setMarketSession] = useState<MarketSession>('NEW YORK');
  const [preEmotion, setPreEmotion] = useState<EntryEmotion>('CONFIDENT');
  const [entryPrice, setEntryPrice] = useState('');
  const [slPrice, setSlPrice] = useState('');
  const [tpPrice, setTpPrice] = useState('');
  const [lotSize, setLotSize] = useState('0.03');
  const [confluences, setConfluences] = useState<string[]>([]);
  const [whyReason, setWhyReason] = useState('');
  const [mentor, setMentor] = useState('');

  useEffect(() => {
    const now = new Date();
    const localISOTime = new Date(now.getTime() - now.getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 16);
    setDate(localISOTime);
  }, []);

  // Update lot size when pair changes or settings update
  useEffect(() => {
    const specificLot = settings.defaultLots?.[pair];
    if (specificLot !== undefined) {
      setLotSize(specificLot.toString());
    } else {
      setLotSize(settings.defaultLotSize.toString());
    }
  }, [pair, settings.defaultLotSize, settings.defaultLots]);

  const risk = calculatePotentialRisk(
    parseFloat(entryPrice),
    parseFloat(slPrice),
    parseFloat(lotSize),
    pair,
    pair === 'Other' ? customPair : undefined
  );

  const isHighRisk = risk > settings.maxDailyRisk;

  const reward = calculatePotentialReward(
    parseFloat(entryPrice),
    parseFloat(tpPrice),
    parseFloat(lotSize),
    pair,
    pair === 'Other' ? customPair : undefined
  );

  const rrRatio = risk > 0 ? (reward / risk).toFixed(2) : '0.00';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (direction === 'BUY' && parseFloat(slPrice) >= parseFloat(entryPrice)) { alert('BUY: SL must be below entry'); return; }
    if (direction === 'SELL' && parseFloat(slPrice) <= parseFloat(entryPrice)) { alert('SELL: SL must be above entry'); return; }
    if (direction === 'BUY' && parseFloat(tpPrice) <= parseFloat(entryPrice)) { alert('BUY: TP must be above entry'); return; }
    if (direction === 'SELL' && parseFloat(tpPrice) >= parseFloat(entryPrice)) { alert('SELL: TP must be below entry'); return; }

    const trade: Trade = {
      id: crypto.randomUUID(),
      date,
      pair,
      customPair: pair === 'Other' ? customPair : undefined,
      direction,
      setup,
      marketSession,
      preEmotion,
      entryPrice: parseFloat(entryPrice),
      slPrice: parseFloat(slPrice),
      tpPrice: parseFloat(tpPrice),
      lotSize: parseFloat(lotSize),
      confluences,
      whyReason,
      mentor,
      commission: 0,
      status: 'OPEN',
    };
    onExecute(trade);
    // Reset form except lot size and date
    setEntryPrice('');
    setSlPrice('');
    setTpPrice('');
    setWhyReason('');
    setMentor('');
    setConfluences([]);
  };

  const handleConfluenceChange = (label: string) => {
    setConfluences(prev => 
      prev.includes(label) ? prev.filter(c => c !== label) : [...prev, label]
    );
  };

  return (
    <div className="bento-card h-full">
      <div className="card-title text-[10px] font-black uppercase text-text-dim tracking-[0.2em] mb-8 flex items-center justify-between border-b border-border pb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
          <span>Execution Module</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[9px] opacity-40">System v2.0</span>
          <Lock className="w-3 h-3 opacity-20" />
        </div>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col h-full space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="bento-label !mb-0 flex items-center gap-2 opacity-70">
              <Zap className="w-3 h-3" /> Pair
            </label>
            <select
              value={pair}
              onChange={(e) => setPair(e.target.value as AssetPair)}
              className="bento-input font-bold tracking-tight bg-black/40 border-white/10 focus:border-primary/50 text-[11px]"
            >
              <option value="XAUUSD">XAUUSD</option>
              <option value="BTCUSD">BTCUSD</option>
              <option value="XAGUSD">XAGUSD</option>
              <option value="EURUSD">EURUSD</option>
              <option value="Other">OTHER</option>
            </select>
          </div>

          {pair === 'Other' && (
            <div className="space-y-1.5 animate-in fade-in slide-in-from-top-2">
              <label className="bento-label !mb-0 flex items-center gap-2 opacity-70">
                <Target className="w-3 h-3" /> Asset ID
              </label>
              <input
                type="text"
                value={customPair}
                onChange={(e) => setCustomPair(e.target.value)}
                placeholder="GBPJPY"
                className="bento-input font-black uppercase tracking-widest text-[11px] bg-black/40 border-white/10 focus:border-primary/50"
                required
              />
            </div>
          )}

          <div className="space-y-1.5">
            <label className="bento-label !mb-0 flex items-center gap-2 opacity-70">
              <Target className="w-3 h-3" /> Direction
            </label>
            <select
              value={direction}
              onChange={(e) => setDirection(e.target.value as Direction)}
              className={cn(
                "bento-input font-black tracking-tight transition-colors",
                direction === 'BUY' ? "text-success bg-success/5 border-success/20" : "text-danger bg-danger/5 border-danger/20"
              )}
            >
              <option value="BUY">BUY / LONG</option>
              <option value="SELL">SELL / SHORT</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 pt-2 border-t border-border/20">
          <div className="space-y-1.5">
            <label className="bento-label opacity-70 uppercase tracking-widest text-[9px]">Setup Type</label>
            <select
              value={setup}
              onChange={(e) => setSetup(e.target.value)}
              className="bento-input text-[11px] font-bold bg-black/40 border-white/10"
            >
              <option value="FVG">FVG</option>
              <option value="OB">ORDER BLOCK</option>
              <option value="BREAKOUT">BREAKOUT</option>
              <option value="SCALPING">SCALPING</option>
              <option value="OTHER">OTHER</option>
            </select>
          </div>
          <div className="space-y-1.5">
            <label className="bento-label opacity-70 uppercase tracking-widest text-[9px]">Active Session</label>
            <select
              value={marketSession}
              onChange={(e) => setMarketSession(e.target.value)}
              className="bento-input text-[11px] font-bold bg-black/40 border-white/10"
            >
              <option value="LONDON">LONDON</option>
              <option value="NEW YORK">NEW YORK</option>
              <option value="ASIA">ASIA</option>
            </select>
          </div>
        </div>

        <div className="space-y-1.5 pt-2 border-t border-border/20">
          <label className="bento-label opacity-70 uppercase tracking-widest text-[9px]">Pre-Trade Mindset</label>
          <div className="grid grid-cols-4 gap-2">
            {['CONFIDENT', 'FEAR', 'FOMO', 'REVENGE'].map((emotion) => (
              <button
                key={emotion}
                type="button"
                onClick={() => setPreEmotion(emotion)}
                className={cn(
                  "py-2 rounded-lg text-[9px] font-black uppercase tracking-tighter border transition-all",
                  preEmotion === emotion 
                    ? "bg-primary text-white border-primary shadow-[0_0_10px_rgba(59,130,246,0.3)]" 
                    : "bg-black/40 border-white/10 text-white/40 hover:border-white/20"
                )}
              >
                {emotion}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4 pt-2 border-t border-border/50">
          <div className="grid grid-cols-1 gap-4">
            <div className="space-y-1.5">
              <label className="bento-label opacity-70 uppercase tracking-widest text-[9px]">Entry Point</label>
              <div className="relative group">
                <input
                  type="number"
                  step="0.01"
                  value={entryPrice}
                  onChange={(e) => setEntryPrice(e.target.value)}
                  onKeyDown={(e) => ['e', 'E', '+', '-'].includes(e.key) && e.preventDefault()}
                  placeholder="0.00"
                  className="bento-input pl-8 font-mono font-bold text-sm"
                  required
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] font-black opacity-20 group-focus-within:opacity-100 transition-opacity whitespace-nowrap">$</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="bento-label opacity-70 uppercase tracking-widest text-[9px]">Stop Loss</label>
              <input
                type="number"
                step="0.01"
                value={slPrice}
                onChange={(e) => setSlPrice(e.target.value)}
                onKeyDown={(e) => ['e', 'E', '+', '-'].includes(e.key) && e.preventDefault()}
                className="bento-input font-mono text-xs border-danger/10 focus:border-danger/40 focus:ring-danger/5"
                required
              />
            </div>
            <div className="space-y-1.5">
              <label className="bento-label opacity-70 uppercase tracking-widest text-[9px]">Take Profit</label>
              <input
                type="number"
                step="0.01"
                value={tpPrice}
                onChange={(e) => setTpPrice(e.target.value)}
                onKeyDown={(e) => ['e', 'E', '+', '-'].includes(e.key) && e.preventDefault()}
                className="bento-input font-mono text-xs border-success/10 focus:border-success/40 focus:ring-success/5"
                required
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="bento-label opacity-70 uppercase tracking-widest text-[9px]">Execution Time</label>
            <input
              type="datetime-local"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="bento-input text-[10px] py-2 bg-black/40 border-white/10 focus:border-primary/50"
              required
            />
          </div>
          <div className="space-y-1.5">
            <label className="bento-label opacity-70 uppercase tracking-widest text-[9px]">Signal Source</label>
            <input
              type="text"
              value={mentor}
              onChange={(e) => setMentor(e.target.value)}
              placeholder="Source..."
              className="bento-input text-[10px] py-2 bg-black/40 border-white/10 focus:border-primary/50"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
             <div className="flex justify-between items-center">
                <label className="bento-label opacity-70 uppercase tracking-widest text-[9px]">Lots</label>
                <div className="text-[9px] font-black text-primary px-1 bg-primary/5 rounded border border-primary/10">
                  R:R: {rrRatio}
                </div>
             </div>
            <input
              type="number"
              step="0.001"
              value={lotSize}
              onChange={(e) => setLotSize(e.target.value)}
              onKeyDown={(e) => ['e', 'E', '+', '-'].includes(e.key) && e.preventDefault()}
              className="bento-input font-bold"
              required
            />
          </div>
        </div>

        {risk > 0 && tpPrice && (
          <div className={cn(
            "grid grid-cols-2 gap-3 transition-all duration-300",
          )}>
            <div className={cn(
              "p-3 rounded-2xl border bg-black/40 flex flex-col items-center justify-center gap-1",
              isHighRisk ? "border-danger/50 shadow-[0_0_20px_rgba(244,63,94,0.2)]" : "border-white/5"
            )}>
              <span className="text-[8px] font-black uppercase text-white/30 tracking-widest">Potential Loss</span>
              <span className={cn("text-base font-black font-mono leading-none", isHighRisk ? "text-danger" : "text-white/80")}>
                -${risk.toFixed(2)}
              </span>
              {isHighRisk && (
                <div className="flex items-center gap-1 mt-1">
                  <Lock className="w-2.5 h-2.5 text-danger" />
                  <span className="text-[7px] font-black text-danger uppercase">LIMIT REACHED</span>
                </div>
              )}
            </div>

            <div className="p-3 rounded-2xl border border-white/5 bg-black/40 flex flex-col items-center justify-center gap-1">
              <span className="text-[8px] font-black uppercase text-white/30 tracking-widest">Potential Win</span>
              <span className="text-base font-black text-success font-mono leading-none">+${reward.toFixed(2)}</span>
              <div className="flex items-center gap-1 mt-1">
                <Target className="w-2.5 h-2.5 text-success/40" />
                <span className="text-[7px] font-black text-white/40 uppercase">R:R {rrRatio}</span>
              </div>
            </div>
          </div>
        )}

        <div className="space-y-2">
          <label className="bento-label">Confluences</label>
          <div className="flex flex-wrap gap-2">
            {CONFLUENCES.map((conf) => {
              const isActive = confluences.includes(conf.label);
              return (
                <button
                  key={conf.id}
                  type="button"
                  onClick={() => handleConfluenceChange(conf.label)}
                  className={cn(
                    "px-3 py-1.5 rounded-full text-[10px] font-bold transition-all border",
                    isActive 
                      ? "bg-primary text-white border-primary shadow-sm" 
                      : "bg-white text-text-dim border-border hover:border-text-dim/30 hover:bg-slate-50"
                  )}
                >
                  {conf.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-1">
          <label className="bento-label flex items-center gap-2">
            <Info className="w-3 h-3 text-primary" />
            Strategic Intent (Why?)
          </label>
          <textarea
            value={whyReason}
            onChange={(e) => setWhyReason(e.target.value)}
            placeholder="Operational purpose/setup description..."
            rows={2}
            className="bento-input resize-none h-16 text-[11px] bg-black/40 border-white/10"
            required
          />
        </div>

        <div className="mt-auto pt-2">
          <div className="bg-amber-50 p-3 rounded-lg border-l-4 border-amber-400 mb-4">
            <p className="text-[10px] text-amber-800 font-bold leading-tight">
              COMMITMENT: I will not touch this trade until TP or SL is triggered.
            </p>
          </div>

          <button type="submit" className="bento-button flex items-center justify-center gap-2 group">
            <Zap className="w-4 h-4 fill-current group-hover:animate-pulse" />
            EXECUTE TRADE
          </button>
          <p className="text-[9px] text-text-dim text-center mt-2 italic">
            Trades appear in History for review after execution.
          </p>
        </div>
      </form>
    </div>
  );
}
