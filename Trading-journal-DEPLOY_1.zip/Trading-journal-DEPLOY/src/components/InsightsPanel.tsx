import React, { useMemo } from 'react';
import { Trade } from '../types';
import { Lightbulb, AlertTriangle, TrendingDown, Zap } from 'lucide-react';
import { calcRealizedRR } from '../lib/utils';

interface InsightsPanelProps {
  trades: Trade[];
}

export function InsightsPanel({ trades }: InsightsPanelProps) {
  const closedTrades = useMemo(() => trades.filter(t => t.status === 'CLOSED'), [trades]);

  const insights = useMemo(() => {
    const messages: { type: string; icon: React.ReactNode; text: string }[] = [];
    if (closedTrades.length === 0) return [];

    const totalPnL = closedTrades.reduce((acc, t) => acc + (t.pnl || 0), 0);
    const wins = closedTrades.filter(t => (t.pnl || 0) > 0).length;
    const winRate = (wins / closedTrades.length) * 100;

    const realizedRRs = closedTrades.map(t => calcRealizedRR(t)).filter(rr => rr !== 0);
    const avgRR = realizedRRs.length > 0 ? realizedRRs.reduce((acc, rr) => acc + rr, 0) / realizedRRs.length : 0;

    // Sort by date (UUID id cannot be subtracted)
    let currentStreak = 0;
    const lastTrades = [...closedTrades].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );
    for (const trade of lastTrades) {
      if ((trade.pnl || 0) < 0) currentStreak++;
      else break;
    }

    if (currentStreak >= 3) {
      messages.push({ type: 'danger', icon: <Zap className="w-5 h-5" />, text: '🚨 STOP TRADING NOW — losing streak active. Step away from the terminal immediately.' });
    }
    if (winRate < 40 && closedTrades.length >= 5) {
      messages.push({ type: 'warning', icon: <AlertTriangle className="w-5 h-5" />, text: `⚠️ Win rate is ${winRate.toFixed(1)}% — taking low-quality entries or overtrading. Tighten your filters.` });
    }
    if (totalPnL < 0 && !messages.find(m => m.type === 'danger')) {
      messages.push({ type: 'danger', icon: <TrendingDown className="w-5 h-5" />, text: '⚠️ Currently unprofitable — reduce frequency and focus on A+ confluence only.' });
    }
    if (avgRR < 1.5 && messages.length < 3) {
      messages.push({ type: 'info', icon: <Lightbulb className="w-5 h-5" />, text: `⚖️ Realized R:R is ${avgRR.toFixed(2)} — below 1.5. Stop cutting winners early.` });
    }
    if (totalPnL > 100 && messages.length < 3) {
      messages.push({ type: 'success', icon: <Zap className="w-5 h-5" />, text: '✅ Discipline maintained. Net yield positive. Stick to current execution protocol.' });
    }

    // Danger first, then warning, info, success
    const priority: Record<string, number> = { danger: 0, warning: 1, info: 2, success: 3 };
    return messages.sort((a, b) => priority[a.type] - priority[b.type]).slice(0, 3);
  }, [closedTrades]);

  if (closedTrades.length === 0) return null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {insights.map((insight, idx) => (
        <div key={idx} className={`bento-card border-none flex items-start gap-3 p-4 !bg-opacity-5 transition-all hover:!bg-opacity-10 ${
          insight.type === 'danger' ? 'bg-danger text-danger ring-1 ring-danger/20' :
          insight.type === 'warning' ? 'bg-amber-500 text-amber-500 ring-1 ring-amber-500/20' :
          insight.type === 'success' ? 'bg-success text-success ring-1 ring-success/20' :
          'bg-primary text-primary ring-1 ring-primary/20'
        }`}>
          <div className="mt-0.5 opacity-60">{insight.icon}</div>
          <div>
            <span className="text-[8px] font-black uppercase tracking-[0.2em] opacity-40 block mb-1">Strategic Advisory</span>
            <p className="text-[10px] font-black leading-relaxed tracking-tight">{insight.text}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
