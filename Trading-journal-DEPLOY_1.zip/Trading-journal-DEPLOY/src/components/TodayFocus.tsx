import React, { useMemo } from 'react';
import { Trade } from '../types';
import { ShieldAlert, Zap, Target, AlertTriangle } from 'lucide-react';
import { cn, calcRealizedRR } from '../lib/utils';

interface TodayFocusProps {
  trades: Trade[];
}

export function TodayFocus({ trades }: TodayFocusProps) {
  const focus = useMemo(() => {
    const closedTrades = trades.filter(t => t.status === 'CLOSED');
    if (closedTrades.length === 0) return {
      title: 'First Step Focus',
      message: 'Log your first trade to activate tactical coaching.',
      icon: <Zap className="w-5 h-5 text-primary" />,
      color: 'border-primary/20 bg-primary/5',
    };

    // Losing streak check
    const sorted = [...closedTrades].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    const lastThree = sorted.slice(0, 3);
    const allLosses = lastThree.length >= 3 && lastThree.every(t => (t.pnl || 0) < 0);
    if (allLosses) return {
      title: 'Psychological Lockout',
      message: '🚨 3 CONSECUTIVE LOSSES. Revenge trading risk is critical. Close all charts now.',
      icon: <AlertTriangle className="w-5 h-5 text-danger" />,
      color: 'border-danger/30 bg-danger/10 shadow-[0_0_20px_rgba(244,63,94,0.2)]',
    };

    // Realized RR check
    const realizedRRs = closedTrades.map(t => calcRealizedRR(t)).filter(rr => rr !== 0);
    const avgRR = realizedRRs.length > 0 ? realizedRRs.reduce((acc, rr) => acc + rr, 0) / realizedRRs.length : 0;
    if (avgRR < 1.5 && realizedRRs.length >= 3) return {
      title: 'Mathematical Edge',
      message: '🎯 FOCUS: DO NOT CUT WINNERS. Hold for 1.5R minimum target today. Ignore the noise.',
      icon: <ShieldAlert className="w-5 h-5 text-amber-500" />,
      color: 'border-amber-500/30 bg-amber-500/10',
    };

    // Win rate — recommend actual best setup dynamically
    const wins = closedTrades.filter(t => (t.pnl || 0) > 0).length;
    const winRate = (wins / closedTrades.length) * 100;
    if (winRate < 40) {
      // Find best performing setup from actual data
      const setupStats: Record<string, { pnl: number; total: number }> = {};
      closedTrades.forEach(t => {
        if (t.setup) {
          if (!setupStats[t.setup]) setupStats[t.setup] = { pnl: 0, total: 0 };
          setupStats[t.setup].pnl += t.pnl || 0;
          setupStats[t.setup].total += 1;
        }
      });
      const bestSetup = Object.entries(setupStats).sort((a, b) => b[1].pnl - a[1].pnl)[0];
      const setupName = bestSetup ? bestSetup[0] : 'your best setup';
      return {
        title: 'Selectivity Focus',
        message: `🎯 ACTION: TRADE ONLY ${setupName} SETUPS TODAY. Your edge is concentrated here based on your data.`,
        icon: <Target className="w-5 h-5 text-blue-500" />,
        color: 'border-blue-500/30 bg-blue-500/10',
      };
    }

    return {
      title: 'Execution Flow',
      message: '✅ Metrics look solid. Stay disciplined — protect your capital and stick to the plan.',
      icon: <Zap className="w-5 h-5 text-success" />,
      color: 'border-success/30 bg-success/10',
    };
  }, [trades]);

  return (
    <div className={cn(
      "p-5 rounded-[2rem] border transition-all duration-500 group relative overflow-hidden",
      focus.color
    )}>
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-150 transition-transform duration-700">
        {focus.icon}
      </div>
      <div className="flex items-center gap-4 relative z-10">
        <div className="p-3 bg-white/5 rounded-2xl border border-white/10 group-hover:scale-110 transition-transform shrink-0">
          {focus.icon}
        </div>
        <div>
          <div className="text-[10px] font-black uppercase text-white/40 tracking-[0.3em] mb-1">Actionable Intelligence</div>
          <div className="text-sm font-black text-white italic tracking-tight">{focus.title}</div>
          <p className="text-[11px] font-bold text-white/60 mt-2 leading-relaxed max-w-md">{focus.message}</p>
        </div>
      </div>
      <div className="absolute inset-y-0 w-[2px] bg-white/20 left-0" />
    </div>
  );
}
