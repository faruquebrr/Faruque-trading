export type AssetPair = 'XAUUSD' | 'BTCUSD' | 'XAGUSD' | 'EURUSD' | 'Other';
export type Direction = 'BUY' | 'SELL';
export type TradeStatus = 'OPEN' | 'CLOSED';
export type ExitReason = 'TP' | 'SL' | 'EA' | 'MV' | '';
export type TradingSession = 'LONDON' | 'NEW YORK' | 'TOKYO' | 'SYDNEY' | 'INTER-SESSION';
export type SetupType = 'FVG' | 'OB' | 'BREAKOUT' | 'SCALPING' | 'OTHER';
export type MarketSession = 'ASIA' | 'LONDON' | 'NEW YORK';
export type EntryEmotion = 'CONFIDENT' | 'FEAR' | 'FOMO' | 'REVENGE';

export interface Trade {
  id: string;
  date: string;
  pair: AssetPair;
  customPair?: string;
  direction: Direction;
  entryPrice: number;
  slPrice: number;
  tpPrice: number;
  lotSize: number;
  reason?: string;
  confluences: string[];
  status: TradeStatus;
  exitPrice?: number;
  exitReason?: ExitReason;
  earlyExitReason?: string;
  notes?: string;
  emotionScore?: number;
  preEmotion?: EntryEmotion;
  setup?: SetupType;
  marketSession?: MarketSession;
  whyReason?: string;
  wrongReason?: string;
  pnl?: number;
  mentor?: string;
  commission?: number;
  session?: TradingSession;
}

export interface Settings {
  defaultLotSize: number;
  defaultLots?: Partial<Record<AssetPair, number>>;
  maxDailyRisk: number;
  initialCapital: number;
}
