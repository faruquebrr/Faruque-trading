import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { TradingSession } from '../types';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getTradingSession(): TradingSession {
  const hour = new Date().getUTCHours();
  // Dominant sessions
  if (hour >= 13 && hour < 17) return 'NEW YORK'; // NY Open / London Close overlap
  if (hour >= 8 && hour < 13) return 'LONDON';
  if (hour >= 17 && hour < 22) return 'NEW YORK';
  if (hour >= 0 && hour < 7) return 'TOKYO';
  if (hour >= 22 || hour < 7) return 'SYDNEY';
  return 'INTER-SESSION';
}

export function calcRealizedRR(t: any): number {
  const risk = Math.abs(t.entryPrice - t.slPrice);
  if (risk === 0 || !t.exitPrice) return 0;
  const reward = t.direction === 'BUY'
    ? t.exitPrice - t.entryPrice
    : t.entryPrice - t.exitPrice;
  return reward / risk;
}

export function formatPrice(price: number): string {
  return price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function formatDateTime(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleString([], { 
    year: 'numeric', 
    month: 'short', 
    day: '2-digit', 
    hour: '2-digit', 
    minute: '2-digit' 
  });
}

export function calculatePotentialRisk(entry: number, sl: number, lot: number, pair: string = 'XAUUSD', customPair?: string): number {
  const entryNum = Number(entry);
  const slNum = Number(sl);
  const lotNum = Number(lot);
  if (!entryNum || !slNum || !lotNum) return 0;
  const diff = Math.abs(entryNum - slNum);
  const multiplier = getMultiplier(pair, customPair);
  return diff * lotNum * multiplier;
}

export function calculatePotentialReward(entry: number, tp: number, lot: number, pair: string = 'XAUUSD', customPair?: string): number {
  const entryNum = Number(entry);
  const tpNum = Number(tp);
  const lotNum = Number(lot);
  if (!entryNum || !tpNum || !lotNum) return 0;
  const diff = Math.abs(tpNum - entryNum);
  const multiplier = getMultiplier(pair, customPair);
  return diff * lotNum * multiplier;
}

export function calculatePnL(entry: number, exit: number, lot: number, direction: 'BUY' | 'SELL', pair: string = 'XAUUSD', commission: number = 0, customPair?: string): number {
  const entryNum = Number(entry);
  const exitNum = Number(exit);
  const lotNum = Number(lot);
  const commNum = Number(commission) || 0;

  if (isNaN(entryNum) || isNaN(exitNum) || isNaN(lotNum) || entryNum === 0 || exitNum === 0 || lotNum === 0) return 0;
  
  const diff = direction === 'BUY' ? exitNum - entryNum : entryNum - exitNum;
  const multiplier = getMultiplier(pair, customPair);
  return (diff * lotNum * multiplier) - commNum;
}

function getMultiplier(pair: string, customPair?: string): number {
  const p = (customPair || pair || 'XAUUSD').toUpperCase();
  // Check specific commodities first to avoid general suffix matching
  if (p.includes('XAU') || p.includes('GOLD')) return 100;
  if (p.includes('XAG') || p.includes('SILVER')) return 500;
  if (p.includes('BTC') || p.includes('ETH')) return 1;
  // Standard Forex Majors/Minors
  if (p.includes('USD') || p.includes('EUR') || p.includes('GBP') || p.includes('JPY') || p.includes('AUD')) return 100000;
  return 100;
}
