import React, { useState } from 'react';
import { useTrades } from './hooks/useTrades';
import { PreTradeForm } from './components/PreTradeForm';
import { TradeLog } from './components/TradeLog';
import { ReviewModal } from './components/ReviewModal';
import { DisciplineAnalytics } from './components/DisciplineAnalytics';
import { SettingsPanel } from './components/SettingsPanel';
import { GoldenRules } from './components/GoldenRules';
import { MarketTicker } from './components/MarketTicker';
import { SummaryDashboard } from './components/SummaryDashboard';
import { EquityChart } from './components/EquityChart';
import { InsightsPanel } from './components/InsightsPanel';
import { TodayFocus } from './components/TodayFocus';
import { WeeklySummary } from './components/WeeklySummary';
import { PerformanceBreakdown } from './components/PerformanceBreakdown';
import { StreakTracker } from './components/StreakTracker';
import { Trade } from './types';
import { ShieldAlert, Zap, LayoutDashboard } from 'lucide-react';
import { getTradingSession, cn } from './lib/utils';

export default function App() {
  const { trades, settings, addTrade, updateTrade, deleteTrade, resetAll, updateSettings, importTrades } = useTrades();
  const [selectedTrade, setSelectedTrade] = useState<Trade | null>(null);
  const [isReviewOpen, setIsReviewOpen] = useState(false);

  const todayPnL = trades
    .filter(t => t.status === 'CLOSED' && new Date(t.date).toDateString() === new Date().toDateString())
    .reduce((acc, t) => acc + (t.pnl || 0), 0);

  const riskUsedPercent = Math.min(Math.max((Math.abs(todayPnL) / settings.maxDailyRisk) * 100, 0), 100);
  const isLimitBreached = todayPnL < 0 && Math.abs(todayPnL) >= settings.maxDailyRisk;
  const isNearLimit = todayPnL < 0 && Math.abs(todayPnL) >= settings.maxDailyRisk * 0.7;

  const handleEndTrade = (trade: Trade) => {
    setSelectedTrade(trade);
    setIsReviewOpen(true);
  };

  const handleExport = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(trades));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `gold_journal_backup_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const handleReset = () => {
    if (window.confirm("ARE YOU SURE? This will delete ALL trade records permanently.")) {
      resetAll();
    }
  };

  return (
    <div className="min-h-screen font-sans selection:bg-blue-500/30 p-4 md:p-8">
      <div className="max-w-[1440px] mx-auto">
        <header className="flex flex-col md:flex-row md:items-center justify-between mb-12 px-4 group">
          <div className="flex items-center gap-5">
            <div className="bg-gradient-to-br from-primary to-blue-600 p-3 rounded-2xl shadow-[0_0_20px_rgba(59,130,246,0.5)] ring-1 ring-white/20 relative overflow-hidden">
               <Zap className="w-6 h-6 text-white relative z-10" />
               <div className="absolute inset-0 bg-white/10 animate-pulse" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-white tracking-tighter uppercase leading-none italic">
                Faruque <span className="text-primary not-italic">Exness Trading</span>
              </h1>
              <p className="text-[9px] font-black text-primary uppercase tracking-[0.4em] mt-1.5 opacity-80">
                Precision Scalping Interface v3.0
              </p>
            </div>
          </div>
          
          <div className="flex-1 max-w-md mx-8 hidden xl:block">
            <div className="flex justify-between items-center mb-1.5">
              <span className="text-[9px] font-black uppercase text-white/40 tracking-widest">Daily Risk Guard</span>
              <span className={cn(
                "text-[9px] font-black uppercase font-mono tracking-widest",
                isLimitBreached ? "text-danger" : todayPnL < 0 ? "text-amber-500" : "text-success"
              )}>
                {todayPnL < 0 ? `-$${Math.abs(todayPnL).toFixed(2)}` : `+$${todayPnL.toFixed(2)}`} / <span className="text-white/20">${settings.maxDailyRisk} Limit</span>
              </span>
            </div>
            <div className="h-1.5 bg-white/5 rounded-full overflow-hidden border border-white/5">
              <div 
                className={cn(
                  "h-full transition-all duration-700",
                  isLimitBreached ? "bg-danger" : isNearLimit ? "bg-amber-500" : "bg-primary"
                )}
                style={{ width: `${riskUsedPercent}%` }}
              />
            </div>
          </div>

          <div className="text-right mt-6 md:mt-0 flex items-center gap-6">
            <div className="hidden lg:flex flex-col text-right">
               <span className="text-[9px] font-black uppercase text-text-dim tracking-widest opacity-40">Active Session</span>
               <span className="text-[11px] font-bold text-success flex items-center justify-end gap-2 uppercase font-mono">
                 <div className="w-1.5 h-1.5 rounded-full bg-success animate-ping" />
                 {getTradingSession()}
               </span>
            </div>
            <div className="font-mono text-[12px] font-black text-white bg-slate-900 shadow-xl px-5 py-2.5 rounded-xl border border-border inline-flex items-center gap-3 transition-all hover:bg-slate-800">
               <ShieldAlert className="w-4 h-4 text-primary" />
               {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
            </div>
          </div>
        </header>

        {isLimitBreached && (
          <div className="mb-8 p-4 bg-danger/10 border-2 border-danger/20 rounded-3xl flex items-center justify-center gap-5 animate-pulse shadow-[0_0_30px_rgba(244,63,94,0.1)]">
            <ShieldAlert className="w-8 h-8 text-danger" />
            <div className="text-center">
              <h3 className="text-xl font-black text-danger uppercase tracking-tighter">DAILY LOSS LIMIT REACHED</h3>
              <p className="text-[10px] font-bold text-danger/60 uppercase tracking-widest leading-none mt-1">Operational Lockdown Initialized — TERMINATE TRADING IMMEDIATELY</p>
            </div>
          </div>
        )}

        <main className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Action Sidebar */}
          <div className="lg:col-span-3 lg:sticky lg:top-8 space-y-8">
            <PreTradeForm onExecute={addTrade} settings={settings} />
            <GoldenRules />
          </div>
          
          {/* Analytical Surface */}
          <div className="lg:col-span-9 space-y-12">
            <MarketTicker />
            
            <header className="flex flex-col md:flex-row md:items-center justify-between mb-2">
              <div className="flex items-center gap-4">
                <div className="bg-primary/10 p-2.5 rounded-2xl border border-primary/20">
                   <LayoutDashboard className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h1 className="text-xl font-black text-white tracking-widest uppercase">
                    Execution <span className="text-primary italic">Terminal</span>
                  </h1>
                </div>
              </div>
              <div className="flex items-center gap-4 mt-4 md:mt-0">
                 <div className="text-right">
                    <span className="text-[8px] font-black text-white/20 uppercase tracking-[0.2em] block">Security Protocol</span>
                    <span className="text-[10px] font-black text-success uppercase flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
                      Encrypted Stream Active
                    </span>
                 </div>
              </div>
            </header>

            <SummaryDashboard 
              trades={trades} 
              initialCapital={settings.initialCapital} 
            />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
               <WeeklySummary trades={trades} />
               <StreakTracker trades={trades} />
            </div>

            <PerformanceBreakdown trades={trades} />

            <EquityChart 
              trades={trades} 
              initialCapital={settings.initialCapital} 
            />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
               <TodayFocus trades={trades} />
               <InsightsPanel trades={trades} />
            </div>

            <TradeLog 
              trades={trades} 
              onEndTrade={handleEndTrade} 
              onDelete={deleteTrade} 
              onEdit={handleEndTrade}
            />

            <DisciplineAnalytics 
              trades={trades} 
              initialCapital={settings.initialCapital} 
            />
            
            <SettingsPanel 
              settings={settings} 
              onUpdate={updateSettings} 
              onExport={handleExport}
              onReset={handleReset}
              onImport={importTrades}
            />
          </div>
        </main>
      </div>

      <ReviewModal 
        trade={selectedTrade} 
        isOpen={isReviewOpen} 
        onClose={() => setIsReviewOpen(false)} 
        onSave={updateTrade} 
      />
    </div>
  );
}
