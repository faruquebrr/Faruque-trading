# Faruque Exness Trading Journal

A precision trading journal for Exness scalpers — built with React, TypeScript, Vite, and Tailwind CSS.

## Deploy to Vercel

### Option A — GitHub (recommended)
1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → New Project → Import your repo
3. Vercel auto-detects Vite — click Deploy

### Option B — Vercel CLI
```bash
npm install -g vercel
cd Trading-journal-DEPLOY
npm install
vercel
```

### Option C — Drag & Drop
Go to [vercel.com/new](https://vercel.com/new) and drag the folder in.

## Local Development
```bash
npm install
npm run dev
# Open http://localhost:3000
```

## Build
```bash
npm run build
# Output in dist/
```

## Features
- Live trade entry with SL/TP validation
- Equity curve with drawdown shading
- Profit Factor, Expectancy, Calmar Ratio, Realized R:R
- Per-pair, per-session, per-setup, per-weekday breakdown
- Weekly review with emotion pattern detection
- Daily loss limit enforcement with visual gauge
- Table view + card view toggle for trade log
- JSON backup export & import
- TradingView live tickers: XAUUSD, XAGUSD, BTCUSD, EURUSD
